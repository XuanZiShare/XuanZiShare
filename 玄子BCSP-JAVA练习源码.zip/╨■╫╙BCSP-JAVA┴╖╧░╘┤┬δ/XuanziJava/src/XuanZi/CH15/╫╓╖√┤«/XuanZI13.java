package XuanZi.CH15.字符串;

import java.util.Scanner;

public class XuanZI13 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("输个数");
        XuanZI12.gaoji(input.next(), "/");

    }
}
