package XuanZi.CH15.字符串;

//拼接字符串
public class XuanZi03 {
    public static void main(String[] args) {
        String name = "张三";
        String age = "20";
        name.concat(age);
        String s = name.concat(age);
        System.out.println(name.concat(age));
        System.out.println(name.concat("50"));
        System.out.println(s);
    }
}
