package XuanZi.CH15.字符串;

//按要求拆分
public class XuanZi07 {
    public static void main(String[] args) {
        String name = "山东菏泽曹县,牛逼666,我的宝贝儿";
        String[] me = name.split(",");
        for (int i = 0; i < me.length; i++) {
            System.out.println(me[i]);
        }
    }
}
