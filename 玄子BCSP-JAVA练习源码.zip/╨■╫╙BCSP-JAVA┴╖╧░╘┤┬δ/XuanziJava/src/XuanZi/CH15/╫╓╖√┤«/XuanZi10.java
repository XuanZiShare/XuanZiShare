package XuanZi.CH15.字符串;

//StringBuffer的使用
public class XuanZi10 {
    public static void main(String[] args) {
        StringBuffer buffer = new StringBuffer("dwadawdadawd,");
        System.out.println(buffer.append(12342e2));
        System.out.println(buffer);


        buffer.insert(2, "dwadawdadawd");
        System.out.println(buffer);

    }
}
