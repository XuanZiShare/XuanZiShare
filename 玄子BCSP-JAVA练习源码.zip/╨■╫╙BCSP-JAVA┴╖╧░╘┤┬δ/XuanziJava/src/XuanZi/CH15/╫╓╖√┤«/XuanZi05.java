package XuanZi.CH15.字符串;
//判断文件后缀

import java.util.Scanner;

public class XuanZi05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("输入一个文件");
        String jie = input.next();
        int i = jie.lastIndexOf(".");

        if (i != 0 && i != -1 && ".java".equals(jie.substring(i))) {
            System.out.println("登录成功");
        } else {
            System.out.println("错误");
        }

    }
}
