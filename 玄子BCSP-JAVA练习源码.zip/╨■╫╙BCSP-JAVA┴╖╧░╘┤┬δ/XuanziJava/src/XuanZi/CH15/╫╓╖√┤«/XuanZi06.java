package XuanZi.CH15.字符串;
//判断文件后缀

import java.util.Scanner;

public class XuanZi06 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("输入一个文件");
        String jie = input.next();
        int jie1 = jie.length();
        //获取字符串长度
        int q = jie1 - 5;
        //查找最后第5位，也就是.
        String p = jie.substring(q, jie1);
        //获取输入字符串最后5位，也就是.java
        System.out.println(p);
        if (".java".equals(p)) {
//            判断是否相等
            System.out.println("正确");
        } else {
            System.out.println("错误");
        }
    }
}