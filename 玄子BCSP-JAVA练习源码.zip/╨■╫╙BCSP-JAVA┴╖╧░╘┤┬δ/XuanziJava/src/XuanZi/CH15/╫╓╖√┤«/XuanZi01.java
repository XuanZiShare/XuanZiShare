package XuanZi.CH15.字符串;

import java.util.Scanner;

//字符串的比较
public class XuanZi01 {
    public static void main(String[] args) {
        String zh = "zh";
        Scanner input = new Scanner(System.in);
        System.out.println("请输入账号");
        String line = input.next();

        if (line.toUpperCase().equals(zh.toLowerCase())) {
            System.out.println("注册失败");
        } else {
            System.out.println("注册成功");
        }
    }
}
