package XuanZi.CH15.字符串;

public class XuanZI12 {
    public static void gaoji(String str, String fu) {
        StringBuffer buffer = new StringBuffer(str);

        for (int i = buffer.length() - 3; i > 0; i -= 3) {
            buffer.insert(i, fu);
        }
        System.out.println(buffer);
    }
}
