package XuanZi.CH15.字符串;
//限定条件判断

import java.util.Scanner;

public class XuanZi08 {
    public static void main(String[] args) {
        Scanner inpout = new Scanner(System.in);
        System.out.println("手机号");
        String sj = inpout.next();
        System.out.println("身份证号");
        String sf = inpout.next();
        System.out.println("座机号");
        String zj = inpout.next();

        if (sj.length() == 11) {
            System.out.println("sj对");
        } else {
            System.out.println("sj错");
        }
        if (sf.length() == 18) {
            System.out.println("sf对");
        } else {
            System.out.println("sf错");
        }

        String substring = zj.substring(4, 5);
        System.out.println(substring);
        if (zj.length() == 12 && "-".equals(substring)) {
            System.out.println("zj对");
        } else {
            System.out.println("zj错");
        }
    }
}
