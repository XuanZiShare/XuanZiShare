package XuanZi.CH15.字符串;

import java.util.Scanner;

//字符串的比较
public class XuanZi02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String name = null;
        String pwd1 = null;
        String pwd2 = null;
        String jiename = null;
        String jiepwd1 = null;
        String jiepwd2 = null;
        boolean is = false;
        System.out.println("*****欢迎进入注册系统*****");
        do {
            is = false;
            for (int i = 1; i <= 3; i++) {
                System.out.println("请输入用户名：");
                jiename = input.next();
                System.out.println("请输入密码：");
                jiepwd1 = input.next();
                System.out.println("请再次输入密码：");
                jiepwd2 = input.next();
                if (jiepwd1.equals(jiepwd2)) {
                    System.out.println("登录成功");
                    is = true;
                    break;
                } else {
                    System.out.println("两次密码不一样");

                }
                System.out.println("你还有" + (3 - i) + "次机会");
                if (i == 3) {

                    break;
                }

            }
        } while (is == true);
        if (is == true) {
            System.out.println("注册成功！");
        } else {
            System.out.println("没机会了");
        }

    }
}
