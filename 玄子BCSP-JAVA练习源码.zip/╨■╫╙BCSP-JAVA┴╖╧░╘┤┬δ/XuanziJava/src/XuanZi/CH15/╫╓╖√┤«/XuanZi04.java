package XuanZi.CH15.字符串;

//多种字符串方法的使用
public class XuanZi04 {
    public static void main(String[] args) {
        String ziFuCuan = "3y7823rbhsajq3wo ";

        System.out.println(ziFuCuan.concat("1"));
        //拼接1
        System.out.println();
        System.out.println(ziFuCuan.indexOf(4));
//        查找4
        System.out.println();
        ziFuCuan.lastIndexOf(3);
        //最后出现的
        System.out.println();
        System.out.println(ziFuCuan.substring(5));
        System.out.println();
        System.out.println(ziFuCuan.substring(5, 8));
        System.out.println();
        System.out.println(ziFuCuan.trim());
        System.out.println();
    }
}
