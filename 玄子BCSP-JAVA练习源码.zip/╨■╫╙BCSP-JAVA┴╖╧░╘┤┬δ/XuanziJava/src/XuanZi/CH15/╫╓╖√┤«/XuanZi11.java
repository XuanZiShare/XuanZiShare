package XuanZi.CH15.字符串;

import java.util.Scanner;

public class XuanZi11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("输个数");
        StringBuffer buffer = new StringBuffer(input.next());

        for (int i = buffer.length() - 3; i > 0; i -= 3) {
            buffer.insert(i, ",");
        }
        System.out.println(buffer);
    }
}
