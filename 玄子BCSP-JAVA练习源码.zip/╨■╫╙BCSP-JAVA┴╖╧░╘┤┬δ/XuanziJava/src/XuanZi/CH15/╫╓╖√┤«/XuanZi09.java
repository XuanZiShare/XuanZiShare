package XuanZi.CH15.字符串;
//找有几个想要的字

import java.util.Scanner;

public class XuanZi09 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("一段话：");
        String hua = input.next();
        System.out.println("找的字：");
        String zi = input.next();

        int num = 0;
        //或者使用数组拆分成一个个字在比较
        for (int i = 0; i < hua.length(); i++) {
            String substring = hua.substring(i, i + 1);
            if (substring.equals(zi)) {
                num++;
            }
        }
        System.out.println(num);
    }
}
