package XuanZi.CH08.数组;
//数组以升序降序排序

import java.util.Arrays;
import java.util.Scanner;

public class XuanZi01 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] scores = new int[5];
        //成绩数组
        System.out.println("请输入5位学员的成绩：");
        for (int i = 0; i < scores.length; i++) {
            scores[i] = input.nextInt();

        }

        Arrays.sort(scores);

        System.out.print("学员成绩按升序排列：");
        for (int i = 0; i < scores.length; i++) {
            System.out.print(scores[i] + " ");
        }

        System.out.println("\n");


        System.out.print("学员成绩按降序排列：");
        for (int i = scores.length - 1; i >= 0; i--) {
            System.out.print(scores[i] + " ");
        }
    }
}
