package XuanZi.CH08.数组;

public class XUanZi07 {
    public static void main(String[] args) {
        int[] a = new int[]{10, 20, 30};
        int[] b = new int[]{40, 50, 60};
        int[] xin = new int[a.length + b.length];
        int c = 0;
        System.out.print("第一个数组中的元素:");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i]);
            if (i < a.length - 1) {
                System.out.print(",");
            }
        }
        System.out.println();
        System.out.print("第二个数组中的元素:");
        for (int i = 0; i < a.length; i++) {
            System.out.print(b[i]);
            if (i < b.length - 1) {
                System.out.print(",");
            }
        }
        System.out.println();
        for (int i = 0; i < xin.length; i++) {
            if (i < a.length) {
                xin[i] = a[i];

            } else {
                xin[i] = b[c];
                c++;
            }

        }
        System.out.print("两个数组合并后:");
        for (int i = 0; i < xin.length; i++) {
            System.out.print(xin[i]);
            if (i < xin.length - 1) {
                System.out.print(",");
            }
        }


        System.out.println();


        System.out.print("逆序后:");
        for (int i = 0; i < xin.length; i++) {

            System.out.print((xin[xin.length - i - 1]));
            if (i < xin.length - 1) {
                System.out.print(",");
            }
        }
    }
}
