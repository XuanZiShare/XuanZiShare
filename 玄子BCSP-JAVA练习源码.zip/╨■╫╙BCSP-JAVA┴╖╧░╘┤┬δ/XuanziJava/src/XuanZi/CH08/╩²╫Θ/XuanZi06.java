package XuanZi.CH08.数组;
//数组插入

import java.util.Arrays;

public class XuanZi06 {
    public static void main(String[] args) {
        int[] lao = {18, 17, 55, 19, 51, 45};
        //老数组
        int num = 52;
        //插入数
        int[] xin = new int[lao.length + 1];
        //新数组长度等于老数组长度加一
        for (int i = 0; i < lao.length; i++) {
            xin[i] = lao[i];
            //新数组的i位成语老数组的i位
        }
        xin[lao.length] = num;
        //新数组最后一位等于插入数

        Arrays.sort(xin);
        for (int i = 0; i < xin.length; i++) {
            System.out.println(xin[i]);
            //排序输出
        }


    }
}