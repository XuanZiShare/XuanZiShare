package XuanZi.CH08.数组;

public class XuanZi02 {
    public static void main(String[] args) {
        String[] names = new String[31];
        String[] name2s = new String[]{"dadada", "dadada", "dadada", "dadada"};
        String[] values = {"dadada", "dadada", "dadada", "dadada", "dadada", "dadada"};
        System.out.println(name2s[5]);
    }
}
