package XuanZi.CH08.数组;
//数组计算平均分

import java.util.Scanner;

public class XuanZi03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] scores = new int[5];
        int sum = 0;
        System.out.println("请输入五位同学成绩：");
        for (int i = 0; i < scores.length; i++) {

            scores[i] = input.nextInt();
            sum = sum + scores[i];

        }
        System.out.println("学员的平均分是：" + (double) sum / scores.length);

    }
}
