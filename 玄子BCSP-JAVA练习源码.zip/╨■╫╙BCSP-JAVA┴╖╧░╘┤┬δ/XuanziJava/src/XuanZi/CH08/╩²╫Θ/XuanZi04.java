package XuanZi.CH08.数组;
//数组计算最高分

import java.util.Scanner;

public class XuanZi04 {
    public static void main(String[] args) {
        //计算成绩最大
        Scanner input = new Scanner(System.in);
        int[] scores = new int[5];
        int max = 0;
        System.out.println("请输入五位同学成绩：");
        for (int i = 0; i < scores.length; i++) {
            scores[i] = input.nextInt();
        }

        max = scores[0];
        for (int i = 1; i < scores.length; i++) {
            if (scores[i] > max) {
                max = scores[i];
            }
        }
        System.out.println("考试成绩最高分为：" + max);

    }
}
