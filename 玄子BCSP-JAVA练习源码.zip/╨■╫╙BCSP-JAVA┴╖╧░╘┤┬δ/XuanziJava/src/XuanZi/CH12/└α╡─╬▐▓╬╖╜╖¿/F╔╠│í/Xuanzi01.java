package XuanZi.CH12.类的无参方法.F商场;

public class Xuanzi01 {

    public void guanLiCaiDan() {
        System.out.println("欢迎使用我行我素购物管理系统：");
        System.out.println("1.登录系统");
        System.out.println("2.退出");
        System.out.println("****************************************************************");
    }

    public void zhuCaiDan() {
        System.out.println("我行我素购物管理系统主菜单：");
        System.out.println("****************************************************************");
        System.out.println("1.客户信息管理");
        System.out.println("2.真情回馈");
        System.out.println("****************************************************************");
    }

    public void zhenQingCaiDan() {
        System.out.println("我行我素购物管理系统 > 真情回馈");
        System.out.println("****************************************************************");
        System.out.println("1.幸运大放送");
        System.out.println("2.幸运抽奖");
        System.out.println("2.生日问候");
        System.out.println("****************************************************************");
    }

    public void tuiChu() {
        System.out.println("你已退出");
    }

}
