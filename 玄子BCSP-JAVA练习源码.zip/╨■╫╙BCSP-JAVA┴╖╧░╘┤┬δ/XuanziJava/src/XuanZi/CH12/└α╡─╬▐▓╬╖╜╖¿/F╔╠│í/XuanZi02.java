package XuanZi.CH12.类的无参方法.F商场;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        Xuanzi01 shangChange = new Xuanzi01();
        Scanner input = new Scanner(System.in);
        shangChange.guanLiCaiDan();
        System.out.println("请选择，数字：");
        int jie = input.nextInt();
        switch (jie) {
            case 1:
                shangChange.zhuCaiDan();
                System.out.println("请选择，输入数组或按0返回上一级菜单：");
                int jie1 = input.nextInt();
                switch (jie1) {
                    case 1:
                        break;
                    case 2:
                        shangChange.zhenQingCaiDan();
                        System.out.println("请选择输入数字或按0返回一级菜单：");
                        int jie2 = input.nextInt();
                        switch (jie2) {
                            case 1:
                                break;
                            case 2:
                                break;
                        }
                        break;
                }
                break;
            case 0:
            case 2:
            default:
                shangChange.tuiChu();
                break;
        }
    }
}
