package XuanZi.CH12.类的无参方法.D平均分;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 score = new XuanZi01();

        Scanner input = new Scanner(System.in);

        System.out.print("请输入java成绩：");
        score.java = input.nextInt();

        System.out.print("请输入c#成绩：");
        score.c = input.nextInt();

        System.out.print("请输入db成绩：");
        score.db = input.nextInt();

        int sum = score.sum();
        int avg = score.avg();

        System.out.println("总分：" + sum);
        System.out.println("平均分：" + avg);
    }
}
