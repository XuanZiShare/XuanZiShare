package XuanZi.CH12.类的无参方法.D平均分;

public class XuanZi01 {
    int java;
    int c;
    int db;


    public int sum() {
        return (java + c + db);
    }

    public int avg() {
        return (java + c + db) / 3;
    }

}
