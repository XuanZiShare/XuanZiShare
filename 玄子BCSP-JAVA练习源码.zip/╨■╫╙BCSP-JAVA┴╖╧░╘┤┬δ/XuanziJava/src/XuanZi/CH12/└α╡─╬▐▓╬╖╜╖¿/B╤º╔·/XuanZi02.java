package XuanZi.CH12.类的无参方法.B学生;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 student = new XuanZi01();

        student.xuexi();
        student.shuaSiPin1();
    }
}
