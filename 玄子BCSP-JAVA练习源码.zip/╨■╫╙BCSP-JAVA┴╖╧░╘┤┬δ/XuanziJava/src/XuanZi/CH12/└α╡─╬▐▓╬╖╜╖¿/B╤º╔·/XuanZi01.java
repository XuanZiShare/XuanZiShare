package XuanZi.CH12.类的无参方法.B学生;

public class XuanZi01 {
    public void xuexi() {
        System.out.println("学习");
        shuaSiPin2();
    }

    public void shuaSiPin1() {
//        public 公有的
        System.out.println("刷视频公共");
    }

    private void shuaSiPin2() {
//        private 私有的
        System.out.println("刷视频私有");
    }
}
