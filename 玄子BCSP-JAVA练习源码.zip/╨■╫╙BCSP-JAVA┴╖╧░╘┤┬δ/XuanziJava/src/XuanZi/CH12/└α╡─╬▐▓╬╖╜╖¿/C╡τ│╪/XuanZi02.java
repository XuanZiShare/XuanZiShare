package XuanZi.CH12.类的无参方法.C电池;

public class XuanZi02 {
    public static void main(String[] args) {

        XuanZi01 dianChi = new XuanZi01();

        dianChi.name = "南孚电池";
        dianChi.dianLiang = 100;

        dianChi.name();

        int dian = dianChi.getDianLiang();
        System.out.println("电量：" + dian);
    }
}
