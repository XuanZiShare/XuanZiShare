package XuanZi.CH12.类的无参方法.C电池;

public class XuanZi01 {
    String name;
    int dianLiang;

    public int getDianLiang() {
        return dianLiang;
    }

    public void name() {
        System.out.println(name);
    }
}
