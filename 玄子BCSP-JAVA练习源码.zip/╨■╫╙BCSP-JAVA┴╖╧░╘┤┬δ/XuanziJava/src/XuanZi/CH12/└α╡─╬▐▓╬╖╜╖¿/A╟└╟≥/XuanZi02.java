package XuanZi.CH12.类的无参方法.A抢球;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 autlion = new XuanZi01();

        autlion.color = "000000";

        String fan = autlion.getColor();
        System.out.println(fan);

    }
}
