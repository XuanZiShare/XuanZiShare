package XuanZi.CH12.类的无参方法.A抢球;

public class XuanZi01 {
    String color;

    public String getColor() {
        return color;
    }
}
