package XuanZi.CH12.类的无参方法.E管理员;

public class XuanZi01 {
    String manager;
    String pwd;


    public void show() {
        System.out.println("管理员用户名为：" + manager + "密码为" + pwd);
    }
}
