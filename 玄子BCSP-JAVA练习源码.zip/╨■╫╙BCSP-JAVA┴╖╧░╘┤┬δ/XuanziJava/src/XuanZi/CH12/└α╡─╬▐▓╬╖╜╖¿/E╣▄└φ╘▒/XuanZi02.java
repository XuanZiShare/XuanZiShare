package XuanZi.CH12.类的无参方法.E管理员;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 show = new XuanZi01();
        Scanner inout = new Scanner(System.in);
        show.pwd = "eqweq";
        show.manager = "fsfs";

        show.show();
    }
}
