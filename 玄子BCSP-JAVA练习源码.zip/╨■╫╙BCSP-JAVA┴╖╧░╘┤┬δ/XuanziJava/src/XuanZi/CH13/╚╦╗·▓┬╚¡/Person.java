package XuanZi.CH13.人机猜拳;

import java.util.Scanner;

public class Person {
    Scanner input = new Scanner(System.in);

    String name;
    int jiFen;

    public int chuQuan() {
        System.out.println("请出拳1.剪刀2.石头3.布");
        int num = input.nextInt();
        switch (num) {
            case 1:
                System.out.println("你出拳：剪刀");
                break;
            case 2:
                System.out.println("你出拳：石头");
                break;
            case 3:
                System.out.println("你出拳：布");
                break;
            default:
                break;
        }

        return num;
    }
}
