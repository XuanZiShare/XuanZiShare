package XuanZi.CH13.人机猜拳;

public class Computer {
    String name;

    int jiFen;

    public int chuQuan() {
        int num = (int) (Math.random() * 3 + 1);

        switch (num) {
            case 1:
                System.out.println(name + "出拳：剪刀");
                break;
            case 2:
                System.out.println(name + "出拳：石头");
                break;
            case 3:
                System.out.println(name + "出拳：布");
                break;
            default:
                break;
        }

        return num;
    }
}
