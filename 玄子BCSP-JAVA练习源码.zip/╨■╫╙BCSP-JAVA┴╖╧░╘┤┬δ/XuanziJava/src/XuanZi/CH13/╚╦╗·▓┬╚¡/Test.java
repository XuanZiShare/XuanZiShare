package XuanZi.CH13.人机猜拳;

public class Test {
    public static void main(String[] args) {
        Game game = new Game();
        Person person = new Person();
        Computer computer = new Computer();
        game.person = person;
        game.computer = computer;
        game.chuShiHua();


    }
}
