package XuanZi.CH13.人机猜拳;

import java.util.Scanner;

public class Game {
    Person person;
    //人玩家
    Computer computer;
    //电脑玩家
    int renQuan;
    int dianQuan;
    int ju = 0;
    //局数
    String isContinue;
    Scanner input = new Scanner(System.in);

    //方法
    //1、初始化：选人
    public void chuShiHua() {
        System.out.println("欢迎进入游戏世界");
        System.out.println("猜拳开始");
        System.out.println("出拳规则：1.剪刀2.石头3.布");
        System.out.print("请选择对方角色1.刘备2.孙权3.曹操");
        int num = input.nextInt();
        switch (num) {
            case 1:
                computer.name = "刘备";
                break;
            case 2:
                computer.name = "孙权";
                break;
            case 3:
                computer.name = "曹操";
                break;
        }
        System.out.println("请输入您的名字：");
        person.name = input.next();
        System.out.println(person.name + "\tVS\t" + computer.name + "对战");
        kaiShiYouXi();
    }

    //2、开始游戏：人出拳、电脑出拳
    public void kaiShiYouXi() {
        System.out.println("要开始吗(y/n)");
        String result = input.next();
        if ("y".equals(result)) {
            do {
                ju++;
                renQuan = person.chuQuan();
                //作弊
//                   if(renQuan==1){
//                       dianQuan=3;
//                   }else if(renQuan==2){
//                       dianQuan=1;
//                   }else {
//                       dianQuan=2;
//                   }
                dianQuan = computer.chuQuan();

                jiSuanDanJu();
                System.out.println("是否继续下一轮");
                isContinue = input.next();
            } while ("y".equals(isContinue));

            zuiZhong();
        } else {
            System.out.println("再等等");
        }

    }

    //3、计算单局结果
    public void jiSuanDanJu() {
        //人赢了
        if ((renQuan == 1 && dianQuan == 3) || (renQuan == 2 && dianQuan == 1) || (renQuan == 3 && dianQuan == 2)) {
            System.out.println("恭喜，你赢了");
            person.jiFen++;
        } else if (renQuan == dianQuan) {
            System.out.println("平局");
        } else {
            System.out.println("电脑赢了");
            computer.jiFen++;
        }
        //人输了
        //平局

    }

    //4、最终比分
    public void zuiZhong() {
        System.out.println(person.name + "\tVS\t" + computer.name + "对战");
        System.out.println("对战次数" + ju);
        System.out.println("姓名\t得分");
        System.out.println(person.name + "\t" + person.jiFen);
        System.out.println(computer.name + "\t" + computer.jiFen);
        if (person.jiFen > computer.jiFen) {
            System.out.println("牛蛙牛蛙");
        } else if (person.jiFen < computer.jiFen) {
            System.out.println("就这？？？");
        } else {
            System.out.println("平局");
        }
    }

}
