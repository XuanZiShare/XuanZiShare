package XuanZi.CH10.幸运抽奖;

import java.util.Scanner;

public class XuanZi03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String yORn = "y";
        String yhm = "";
        String mm = "";
        int k = 0;
        int hykh = (int) (Math.random() * 9000 + 1000);
        //随机数取证后最大是8999+1000是9999
        //随机数取证后最小是0+1000是1000
        do {
            yORn = "";
            System.out.println("*******欢迎进入奖客富翁系统*******");
            System.out.println("\t\t1.注册\n\t\t2.登录\n\t\t3.抽奖");
            System.out.println("******************************");
            System.out.print("请选择菜单：");
            if (input.hasNextInt()) {
                int i = input.nextInt();
                switch (i) {
                    case 1:
                        System.out.println("【奖客富翁系统 > 注册】");
                        System.out.println("请填写个人注册信息：");
                        System.out.print("用户名：");
                        yhm = input.next();
                        System.out.print("密码：");
                        mm = input.next();
                        System.out.println("注册成功，请记好您的会员卡号：");
                        System.out.println("用户名\t密码\t\t会员卡号");
                        System.out.println(yhm + "\t\t" + mm + "\t\t" + hykh);
                        System.out.print("是否继续(y/n)");
                        yORn = input.next();

                        break;
                    case 2:
                        System.out.println("【奖客富翁系统 > 登录】");
                        System.out.print("请输入用户名：");
                        yhm = input.next();
                        System.out.print("请输入密码：");
                        mm = input.next();
                        System.out.println("欢迎你" + yhm);
                        System.out.print("是否继续(y/n)");
                        yORn = input.next();
                        break;
                    case 3:
                        System.out.println("【奖客富翁系统 > 抽奖】");
                        System.out.print("请输入您的卡号：");
                        hykh = input.nextInt();
                        int[] kk = new int[6];
                        for (int j = 0; j <= 5; j++) {
                            k = (int) (Math.random() * 10000);
                            kk[j] = k;
                        }

                        System.out.println("本日的幸运数字是：" + kk[0] + "\t" + kk[1] + "\t" + kk[2] + "\t" + kk[3] + "\t" + kk[4] + "\t" + kk[5]);
                        if (hykh == kk[0] || hykh == kk[1] || hykh == kk[2] || hykh == kk[3] || hykh == kk[4] || hykh == kk[5]) {
                            System.out.println("恭喜你是今日的幸运会员，所有物品打8折");
                        } else {
                            System.out.println("抱歉！您不是今日的幸运会员！");
                        }
                        System.out.print("是否继续(y/n)");
                        yORn = input.next();
                        break;
                    default:
                        System.out.println("请输入 1-3 的数字");
                        break;
                }
            } else {
                System.out.println("请输入数字");
            }
        } while (yORn.equals("y") || yORn.equals("Y"));
        System.out.println("系统退出谢谢使用");
    }
}
