package XuanZi.CH10.幸运抽奖;

//幸运抽奖玄子
public class XuanZi04 {
    public static void main(String[] args) {


        for (int i = 0; i < 100; i++) {
            int hykh = (int) (Math.random() * 9000 + 1000);
            //随机数取证后最大是8999+1000是9999
            //随机数取证后最小是0+1000是1000
            System.out.println(hykh);
        }


        for (int i = 0; i < 100; i++) {
            int num = (int) (Math.random() * 11 / 2 + 5);
            System.out.println(num);
        }


        //     4位整数

        //    0-1        0.0000000-0.99999999999
        int num = 0;
        do {
            num = (int) (Math.random() * 10000);
            System.out.println("产生的num:" + num);
        } while (num < 1000);
        System.out.println("合格的num:" + num);


        //    718    911
        int nuum = (int) (Math.random() * (911 - 718 + 1)) + 718;
        System.out.println(nuum);


    }
}


