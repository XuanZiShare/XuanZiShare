package XuanZi.CH10.幸运抽奖;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("*******欢迎进入奖客富翁系统*******");
        System.out.println("\t\t1.注册\n\t\t2.登录\n\t\t3.抽奖");
        System.out.println("******************************");
        System.out.print("请选择菜单：");
        if (input.hasNextInt()) {
            int i = input.nextInt();
            switch (i) {
                case 1:
                    System.out.println("【奖客富翁系统 > 注册】");

                    break;
                case 2:
                    System.out.println("【奖客富翁系统 > 登录】");
                    break;
                case 3:
                    System.out.println("【奖客富翁系统 > 抽奖】");
                    break;
                default:
                    System.out.println("请输入 1-3 的数字");
                    break;
            }
        } else {
            System.out.println("请输入数字");
        }

    }
}
