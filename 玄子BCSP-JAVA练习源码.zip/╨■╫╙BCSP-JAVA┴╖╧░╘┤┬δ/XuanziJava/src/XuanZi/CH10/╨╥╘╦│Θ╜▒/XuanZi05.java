package XuanZi.CH10.幸运抽奖;
//幸运抽奖完整版

import java.util.Scanner;

public class XuanZi05 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String isContinue = "";
        //是否继续
        boolean zhongJiang = true;

        int[] nums = new int[5];
        for (int i = 0; i < nums.length; i++) {
            nums[i] = (int) (Math.random() * (9000) + 1000);
        }
        int cardNum = 0;

        boolean zhengChangRen = true;

        String registerName = "";
        //注册的用户名
        String registerPwd = "";
        //注册的密码

        String loginName = "";
        //登录的用户名
        String loginPwd = "";
        //登录的密码
        int random = 0;

        do {


            System.out.println("************欢迎进入奖客富翁系统************");
            System.out.println("1.注册");
            System.out.println("2.登录");
            System.out.println("3.抽奖");
            System.out.println("*******************************************");
            System.out.println("请请选择菜单：");
            int choice = 0;
            //选择
            if (input.hasNextInt()) {
                //输入合法
                choice = input.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("[奖客富翁系统>注册]");
                        System.out.println("请输入用户名：");
                        registerName = input.next();
                        System.out.println("请输入密码：");
                        registerPwd = input.next();
                        //    4位         1000     9999
                        random = (int) (Math.random() * (9000) + 1000);


                        System.out.println("用户名\t密码\t\t会员卡号");
                        System.out.println(registerName + "\t\t" + registerPwd + "\t\t" + random);
                        break;
                    case 2:
                        System.out.println("[奖客富翁系统>登录]");
                        for (int i = 1; i <= 3; i++) {
                            System.out.println("请输入用户名：");
                            loginName = input.next();
                            System.out.println("请输入密码：");
                            loginPwd = input.next();

                            if (registerName.equals(loginName) && registerPwd.equals(loginPwd)) {
                                System.out.println("登录成功");
                                break;
                            } else {
                                System.out.println("登录失败");
                                System.out.println("您还有" + (3 - i) + "次机会");
                                if (i == 3) {
                                    zhengChangRen = false;
                                    System.out.println("您已用完3次机会，是否返回主菜单");
                                    break;
                                }
                            }
                        }

                        break;
                    case 3:
                        System.out.println("[奖客富翁系统>抽奖]");
                        System.out.println("请输入会员号：");
                        cardNum = input.nextInt();
                        //产生的随机数
                        for (int i = 0; i < nums.length; i++) {
                            System.out.print(nums[i] + "\t");
                        }
                        for (int i = 0; i < nums.length; i++) {
                            if (nums[i] == cardNum) {
                                //中奖了
                                zhongJiang = true;
                                System.out.println("您中奖了");
                                break;
                            } else {
                                zhongJiang = false;
                            }
                        }
                        if (zhongJiang == false) {
                            System.out.println("您没中奖");
                        }


                        break;
                    default:
                        System.out.println("请输入1-3之间的整数");
                        break;
                }
                if (zhengChangRen) {
                    System.out.println("是否继续？（y/n）");
                    isContinue = input.next();
                } else {
                    break;
                }


            } else {
                //输入不合法
                System.out.println("您的输入有误！");
            }


        } while ("y".equals(isContinue) || "Y".equals(isContinue));
    }
}


