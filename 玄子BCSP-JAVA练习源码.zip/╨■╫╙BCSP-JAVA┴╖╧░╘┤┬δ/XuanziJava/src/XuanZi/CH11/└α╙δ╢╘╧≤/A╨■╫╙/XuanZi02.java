package XuanZi.CH11.类与对象.A玄子;


public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 test = new XuanZi01();
        test.name = "玄子";
        test.age = 16;
        test.add = "漯河";
        test.hobby = "计算机";

        test.zi();


    }


}
