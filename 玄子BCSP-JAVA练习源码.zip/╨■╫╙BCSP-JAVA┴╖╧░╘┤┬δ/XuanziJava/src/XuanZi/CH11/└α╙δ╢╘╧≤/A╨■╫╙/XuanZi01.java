package XuanZi.CH11.类与对象.A玄子;

public class XuanZi01 {
    String name;
    int age;
    String add = "";
    String hobby = "";

    public void zi() {
        System.out.println("玄子自我介绍");
        System.out.println(name);
        System.out.println(age);
        System.out.println(add);
        System.out.println(hobby);

    }
}
