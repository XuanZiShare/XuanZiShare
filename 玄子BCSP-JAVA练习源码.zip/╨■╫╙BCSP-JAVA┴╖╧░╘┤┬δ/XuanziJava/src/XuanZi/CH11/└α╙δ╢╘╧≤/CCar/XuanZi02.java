package XuanZi.CH11.类与对象.CCar;

public class XuanZi02 {
    public static void main(String[] args) {
        //inta=10;//写在方法里的变量.局部变量
        //创建对象
        //1nta=10:
        //String color="呵呵"
        //在面向对象的世界里，变量是没有市场的.这种变量被称为引用
        //java分为两种数据类型：1，基本数据类型2，引用数据类型Str1ng和我们创建的所有的类
        XuanZi01 car = new XuanZi01();
        // 创建对象创建了一辆车.后面想用这两车.就需要使用c来访问
        car.run();
        //.表示调用.“的”   // 让车去跑.    //对象或者引用.方法()
        car.color = "绿色";
        car.speed = 120;
        //c.fly = 1.5;   //类中没有定义的内容不可以使用
        System.out.println(car.color);
        System.out.println(car.seat);
        System.out.println(car.speed);

        XuanZi01 car2 = new XuanZi01();
        car2.color = "红色";
        car2.speed = 180;
        car2.seat = 6;

        XuanZi01 car3 = new XuanZi01();
        car3.seat = 6;
        car3.speed = 210;
        car3.color = "11111111";

        System.out.println(car2.color);
        System.out.println(car2.seat);
        System.out.println(car2.speed);
        System.out.println(car3.color);

    }
}
