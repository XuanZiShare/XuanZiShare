package XuanZi.CH11.类与对象.CCar;

public class XuanZi01 {
    //成员变量
    String color;
    //颜色
    int speed;
    //速度
    int seat = 5;
    //座位


    //成员方法
    public void run() {

        System.out.println("车能跑");
    }


}
