package XuanZi.CH11.类与对象.B小黑子;

//创建对象
public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 xuanZi = new XuanZi01();
        xuanZi.me();

        xuanZi.name = "蔡徐坤";

        xuanZi.add = "蔡家村";

        xuanZi.age = 16;

        xuanZi.hobby = "唱跳rap篮球";

        System.out.println("我的名字是：" + xuanZi.name + ",今年" + xuanZi.age + "岁，练习时长两年半。\t家住:" + xuanZi.add + "\t我的爱好是:" + xuanZi.hobby);
        System.out.println();

        XuanZi01 xuanZi01 = new XuanZi01();

        xuanZi.name = "3131";

        xuanZi.add = "31231";

        xuanZi.age = 16;

        xuanZi.hobby = "唱跳rap篮球";

        System.out.println("我的名字是：" + xuanZi.name + ",今年" + xuanZi.age + "岁，练习市场两年半。\t家住:" + xuanZi.add + "\t我的爱好是:" + xuanZi.hobby);
        xuanZi.zi();

    }
}
