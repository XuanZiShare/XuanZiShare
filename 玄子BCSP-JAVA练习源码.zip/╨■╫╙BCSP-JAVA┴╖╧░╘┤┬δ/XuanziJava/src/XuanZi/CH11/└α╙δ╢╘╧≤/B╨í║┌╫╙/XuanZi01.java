package XuanZi.CH11.类与对象.B小黑子;

//定义类
public class XuanZi01 {

    String name;
    int age;
    String add;
    String hobby;


    public void me() {

        System.out.println("我是小黑子");
        System.out.println();

    }

    public void zi() {
        System.out.println("6666");
    }

}
