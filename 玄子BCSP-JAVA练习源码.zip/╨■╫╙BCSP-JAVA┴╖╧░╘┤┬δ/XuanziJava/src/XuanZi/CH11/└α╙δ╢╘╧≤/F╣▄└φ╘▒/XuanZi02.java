package XuanZi.CH11.类与对象.F管理员;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 denglu = new XuanZi01();
        //声明对象对象的名字叫 denglu
        denglu.zhangHao = "admin";
        denglu.password = "12345";
        //给默认的账号，密码赋值
        denglu.xiuGai();
        //调用 xiuGai 的方法
    }
}
