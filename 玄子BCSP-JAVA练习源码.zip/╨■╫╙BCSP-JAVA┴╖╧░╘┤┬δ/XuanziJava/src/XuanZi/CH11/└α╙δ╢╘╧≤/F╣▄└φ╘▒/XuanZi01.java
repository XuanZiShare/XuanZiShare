package XuanZi.CH11.类与对象.F管理员;

import java.util.Scanner;

public class XuanZi01 {
    //定义类

    String zhangHao;
    String password;

    //声明默认账号和密码
    public void xiuGai() {
        //声明 方法 方法的名字叫 xiuGai
        Scanner input = new Scanner(System.in);
        System.out.println("请输入用户名：");
        String shuZhangHao = input.next();
        System.out.println("请输入密码：");
        String shuPassword = input.next();
        //接收用户输入的账号密码
        if (shuPassword.equals(password) && shuZhangHao.equals(zhangHao)) {
            //对用户输入的账号密码进行判断
            System.out.println("登陆成功,请输入新密码：");
            String nwePssword = input.next();
            //提醒用户输入新密码
            password = nwePssword;
            //将默认的密码设置为用户输入的新密码
            System.out.println("修改成功新密码是：" + password);
            //输出修改后的密码
        } else {
            System.out.println("登陆失败，无权限修改密码。");
            //如果账号或密码错误就提醒用户登陆失败
        }

    }
}
