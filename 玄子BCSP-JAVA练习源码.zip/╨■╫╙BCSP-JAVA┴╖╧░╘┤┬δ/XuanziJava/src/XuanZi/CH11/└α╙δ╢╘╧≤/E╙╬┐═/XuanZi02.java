package XuanZi.CH11.类与对象.E游客;

//创建游客对象
public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 yk = new XuanZi01();
        //创建第一个游客
        yk.name = "张三";
        yk.age = 100;

        yk.piao();
        //使用买票方法

        System.out.println();

        XuanZi01 yk2 = new XuanZi01();
        //创建第二个游客
        yk.name = "李四";
        yk.age = 20;
        
        yk.piao();
        //使用买票方法
    }
}
