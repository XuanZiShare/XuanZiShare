package XuanZi.CH11.类与对象.E游客;

//定义游客类
public class XuanZi01 {
    String name;
    int age;

    public void piao() {
        //定义游客是否需要买票方法
        if (age <= 18 || age >= 60) {
            System.out.println(name + "免费");
        } else {
            System.out.println(name + "买票");
        }
    }
}
