package XuanZi.CH11.类与对象.D教员;

public class XuanZi01 {
    String name;
    String zhuan;
    String jiaoKe;
    int jiaoAge;

    public void jiao() {
        System.out.println(name);
        System.out.println("专业方向：" + zhuan);
        System.out.println("教授课程：" + jiaoKe);
        System.out.println("教龄：" + jiaoAge);
    }
}
