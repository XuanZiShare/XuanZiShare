package XuanZi.CH11.类与对象.D教员;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 teacher = new XuanZi01();
        teacher.name = "王老师";
        teacher.zhuan = "计算机";
        teacher.jiaoKe = "使用Java语言理解程序逻辑";
        teacher.jiaoAge = 5;
        teacher.jiao();
    }
}
