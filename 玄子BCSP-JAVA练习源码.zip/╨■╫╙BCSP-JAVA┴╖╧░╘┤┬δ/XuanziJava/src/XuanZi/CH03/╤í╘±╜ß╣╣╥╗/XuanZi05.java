package XuanZi.CH03.选择结构一;

//if多层条件判断递归

import java.util.Scanner;

public class XuanZi05 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("请输入年龄：");
        int num = input.nextInt();

        //接收
    /*
        if (num >= 90){
            System.out.println("快嗝屁了");
        }else if (num < 90 && num >= 50 ){
            System.out.println("老年");
        }else if (num < 50 && num >= 40){
            System.out.println("壮年");
        }else if (num < 40 && num >=30){
            System.out.println("青年");
        }else if (num < 30 && num >=18){
            System.out.println("少年");
        }else if (num < 18 && num >=1){
            System.out.println("未成年");
        }else {
            System.out.println("不是人");
        }
    */

        if (num >= 90) {
            System.out.println("快嗝屁了");
        } else if (num >= 50) {
            System.out.println("老年");
        } else if (num >= 40) {
            System.out.println("壮年");
        } else if (num >= 30) {
            System.out.println("青年");
        } else if (num >= 18) {
            System.out.println("少年");
        } else if (num >= 1) {
            System.out.println("未成年");
        } else {
            System.out.println("不是人");
        }

    }
}