package XuanZi.CH03.选择结构一;
//嵌套if判断

import java.util.Scanner;

public class XuanZI07 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("欢迎来到玄子商场，请输入你想要去的区域");
        System.out.println("1.游戏区");
        System.out.println("2.餐饮区");
        System.out.println("3.服装区");
        System.out.print("请输入你想要去的区域：");
        int jie1 = input.nextInt();
        if (jie1 == 1) {
            System.out.println("欢迎来到游戏区,你想玩什么游戏：");
            System.out.println("1.王者");
            System.out.println("2.吃鸡");
            System.out.println("3.原神");
            System.out.print("请输入你想要玩的游戏：");
            int jie11 = input.nextInt();
            if (jie11 == 1) {
                System.out.println("欢迎来到王者");
            } else if (jie11 == 2) {
                System.out.println("欢迎来到吃鸡");
            } else if (jie11 == 3) {
                System.out.println("欢迎来到原神");
            } else {
                System.out.println("请输入正确数字");
            }

        } else if (jie1 == 2) {
            System.out.println("欢迎来到餐饮区,你想吃什么东西：");
            System.out.println("1.炸鸡");
            System.out.println("2.面条");
            System.out.println("3.米饭");
            System.out.print("请输入你想要吃的食物：");
            int jie12 = input.nextInt();
            if (jie12 == 1) {
                System.out.println("你吃了炸鸡");
            } else if (jie12 == 2) {
                System.out.println("你吃了面条");
            } else if (jie12 == 3) {
                System.out.println("你吃了米饭");
            } else {
                System.out.println("请输入正确数字");
            }

        } else if (jie1 == 3) {
            System.out.println("欢迎来到服装区，你想买什么衣服：");
            System.out.println("1.上衣");
            System.out.println("2.裤子");
            System.out.println("3.鞋子");
            System.out.print("请输入你想要买的衣服：");
            int jie13 = input.nextInt();
            if (jie13 == 1) {
                System.out.println("你买了上衣");
            } else if (jie13 == 2) {
                System.out.println("你买了裤子");
            } else if (jie13 == 3) {
                System.out.println("你买了鞋子");
            } else {
                System.out.println("请输入正确数字");
            }

        } else {
            System.out.println("请输入正确数字");
        }
    }
}

