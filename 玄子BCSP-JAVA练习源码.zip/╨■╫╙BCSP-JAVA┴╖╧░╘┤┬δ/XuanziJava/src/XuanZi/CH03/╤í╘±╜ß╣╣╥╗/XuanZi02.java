package XuanZi.CH03.选择结构一;
//逻辑运算符的使用

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        System.out.print("请输入张三的java成绩：");
        int Java = inout.nextInt();
        System.out.print("请输入张三的音乐成绩：");
        int Music = inout.nextInt();
        if ((Java > 98 && Music > 80) || (Java == 100 && Music > 70)) {
            System.out.println("奖励");
        } else {
            System.out.println("啥也不给");

        }
    }

}
