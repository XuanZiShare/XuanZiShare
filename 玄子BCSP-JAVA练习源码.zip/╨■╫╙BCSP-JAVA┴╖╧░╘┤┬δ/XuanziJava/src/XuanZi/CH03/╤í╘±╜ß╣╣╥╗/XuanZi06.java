package XuanZi.CH03.选择结构一;
//多层if判断、逻辑运算符


import java.util.Scanner;

public class XuanZi06 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String yhm = "abc";
        String zhm = "123";
        System.out.println("请输入用户名：");
        String shuru = input.next();
        System.out.println("请输入密码：");
        String zhuru = input.next();
        if (shuru.equals(yhm) && zhuru.equals(zhm)) {
            System.out.println("输入正确");
        } else {
            System.out.println("输入错误");
        }


        /*
        String 源姓名 = "玄子";
        String 源年龄 = "16";
        System.out.println("请输入姓名：");
        String 姓名 = input.next();
        System.out.println("请输入年龄");
        String 年龄 = input.next();
        if (姓名.equals(源姓名) && 年龄.equals(源年龄)){
            System.out.println("正确");
        }else {
            System.out.println("错误");
        }

         */
    }
}
