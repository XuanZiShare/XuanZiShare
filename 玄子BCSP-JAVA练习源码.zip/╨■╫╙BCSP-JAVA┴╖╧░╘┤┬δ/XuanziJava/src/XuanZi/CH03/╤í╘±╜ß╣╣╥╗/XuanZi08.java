package XuanZi.CH03.选择结构一;
//平年闰年判断器

import java.util.Scanner;

public class XuanZi08 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        System.out.println("欢迎来到闰年平年判断器");
        System.out.println("请输入年份：");
        int year = inout.nextInt();
        if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0) && (year != 0)) {
            System.out.println("这是闰年");
        } else {
            System.out.println("这是平年");
        }
    }
}
