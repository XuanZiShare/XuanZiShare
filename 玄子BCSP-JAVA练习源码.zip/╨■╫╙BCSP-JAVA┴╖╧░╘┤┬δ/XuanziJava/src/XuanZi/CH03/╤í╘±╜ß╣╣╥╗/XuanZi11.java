package XuanZi.CH03.选择结构一;
//输出每位数

import java.util.Scanner;

public class XuanZi11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("请输入随机数：");
        int j = input.nextInt();
/*
        int Gewei = i % 10;
        System.out.println(Gewei);
        int Shiwei = i % 100 / 10;
        System.out.println(Shiwei);
        int Baiwei = i % 1000 / 100;
        System.out.println(Baiwei);
        int Qianwei = i % 10000 / 1000;
        System.out.println(Qianwei);
        int Wanwei = i % 100000 / 10000;
        System.out.println(Wanwei);
*/
        //如果万位=0
        //如果十万位=0
//        int  Gewei,Shiwei,Baiwei,Qianwei,Wanwei,ShiwanWei,BaiwanWei,QianwanWei,YiWei;

        int ChuShu = 10;
        int BeiChuShu = 1;
        int weishu;
        if (j != 0) {
            for (int wei = j; wei != 0; ) {

                for (weishu = j % ChuShu / BeiChuShu; ; ) {
                    System.out.println(weishu);
                    ChuShu *= 10;
                    BeiChuShu *= 10;
                }
            }

//            System.out.println(i % 10);
//            System.out.println(i % 100 / 10);
//            System.out.println(i % 1000 / 100);
        }

    }
}
