package XuanZi.CH03.选择结构一;
//比较运算符的使用

import java.util.Scanner;

public class XuanZi01 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("请输入你的分数：");
        double i = input.nextDouble();
        if (i >= 60) {
            System.out.println("及格了");
        } else {
            System.out.println("不及格");
        }
    }
}
