package XuanZi.CH03.选择结构一;
//逻辑运算符的使用

import java.util.Scanner;

public class XuanZi03 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        System.out.println("中奖了吗？(Y/N)");
        String lin = inout.next();
        if (lin.equals("Y") || lin.equals("y")) {
            System.out.println("中奖了");
        } else {
            System.out.println("进厂吧");
        }


    }
}
