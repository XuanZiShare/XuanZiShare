package XuanZi.CH03.选择结构一;
//随机数的使用

import java.util.Scanner;

public class XuanZi04 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        System.out.print("请输入会员号：");
        int i = inout.nextInt();
        int w = i / 100 % 10;
        int j = (int) (Math.random() * 10);
        if (w == j) {
            System.out.println("幸运客户");
        } else {
            System.out.println("谢谢惠顾");
            System.out.println("幸运号码是：" + j);
        }
    }
}
