package XuanZi.CH06.循环结构二;

import java.util.Scanner;

public class XuanZi08 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        int num = 0;
        System.out.println("请输入有几位同学");
        int student = inout.nextInt();
        for (int i = 1; i <= student; i++) {
            System.out.println("请输入第" + i + "位同学的成绩：");
            int j = inout.nextInt();
            if (j < 80) {
                i--;
                continue;
            }
            num++;
        }
        System.out.println("80分以上的学生人数是： " + num);
    }

}
