package XuanZi.CH06.循环结构二;

import java.util.Scanner;

public class XuanZi07 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int score;
        int num = 0;
        System.out.println("请输入有几位同学");
        int total = input.nextInt();
        for (int i = 0; i < total; i++) {
            System.out.print("请输入第" + (i + 1) + "位学生的成绩： ");
            score = input.nextInt();
            if (score < 80) {
                continue;
            }
            num++;
        }
        System.out.println("80分以上的学生人数是： " + num);
        double rate = num * 1.0 / total * 100;
        //计算比例
        System.out.println("80分以上的学生所占的比例为：" + rate + "%");


    }
}
