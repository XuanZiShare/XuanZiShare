package XuanZi.CH06.循环结构二;

//输出100个数
public class XuanZi01 {
    public static void main(String[] args) {
        for (int i = 1; i <= 100; i++) {
            System.out.println(i);
        }
    }
}
