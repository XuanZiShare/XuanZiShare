package XuanZi.CH06.循环结构二;

//100以内奇数偶数和
public class XuanZi03 {
    public static void main(String[] args) {
        int ouHe = 0;
        int jiHe = 0;
        for (int i = 0; i <= 100; i += 2) {
            ouHe = ouHe + i;

        }
        for (int i = 1; i <= 100; i += 2) {
            jiHe = jiHe + i;

        }
        System.out.println(jiHe + " " + ouHe);
    }
}
