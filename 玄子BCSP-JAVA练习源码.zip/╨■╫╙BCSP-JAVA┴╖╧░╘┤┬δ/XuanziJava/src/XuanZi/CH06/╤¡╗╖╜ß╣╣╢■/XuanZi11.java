package XuanZi.CH06.循环结构二;
//break语句的使用

import java.util.Scanner;

public class XuanZi11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String zbzh = "admin";
        String zbmm = "123456";
        for (int i = 1; i <= 3; i++) {
            System.out.println("请输入账号");
            String zh = input.next();
            System.out.println("请输入密码");
            String mm = input.next();
            if (zh.equals(zbzh) && mm.equals(zbmm)) {
                System.out.println("登录成功");
                break;
            } else {
                System.out.println("登录失败还有" + (3 - i) + "次机会");
                if (i == 3) {
                    System.out.println("没机会了");
                }
            }
        }
    }
}
