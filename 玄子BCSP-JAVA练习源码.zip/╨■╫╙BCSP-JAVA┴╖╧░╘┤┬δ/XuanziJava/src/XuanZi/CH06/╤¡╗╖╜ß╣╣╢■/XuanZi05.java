package XuanZi.CH06.循环结构二;

import java.util.Scanner;

//布尔值在判断中的使用
public class XuanZi05 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        System.out.println("请输入你的姓名：");
        String name = inout.next();
        int score = 0;
        int he = 0;
        boolean panDuan = true;
        //判断是否输出最后的成绩和
        for (int i = 1; i < 5; i++) {
            System.out.println("请输入第" + i + "门成绩");
            score = inout.nextInt();
            he += score;
            if (score < 0) {
                System.out.println("请输入正确成绩！");
                panDuan = false;
//                如果输入错误就不输出最后的和
                break;
            }
        }
        if (panDuan == true) {
            //只有判断是正确才输出最终的和
            System.out.println("成绩和" + he);
        }

    }
}
