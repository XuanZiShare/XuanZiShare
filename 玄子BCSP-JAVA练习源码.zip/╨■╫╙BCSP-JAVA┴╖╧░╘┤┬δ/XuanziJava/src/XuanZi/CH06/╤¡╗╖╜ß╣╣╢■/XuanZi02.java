package XuanZi.CH06.循环结构二;

//100以内奇数偶数和
public class XuanZi02 {
    public static void main(String[] args) {
//        int ouShu = 0;
//        int jiShu = 0;
//        for (int i = 100; i <= 0; i--) {
//            if (i % 2 == 0) {
//                ouShu += i;
//            } else {
//                jiShu += i;
//            }
//
//        }

        int jiShu = 0;
        int ouShu = 0;
        for (int num = 0; num <= 100; num++) {
            if (num % 2 == 0) {
                ouShu += num;
            } else {
                jiShu += num;
            }

        }

        System.out.println(jiShu + " " + ouShu);
    }
}
