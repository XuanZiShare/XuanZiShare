package XuanZi.CH06.循环结构二;
//判断最大最小值

import java.util.Scanner;

public class XuanZi04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num = 0;
        int jie2;
        int max = 0;
        int min = 0;

        System.out.print("请输入一个数字:");
        num = input.nextInt();
        do {
            System.out.print("请输入一个数字:");
            jie2 = input.nextInt();


            if (jie2 > num) {
                max = jie2;
            } else if (jie2 < num) {
                min = jie2;
            }

        } while (jie2 != 0);
        System.out.println(max);
        System.out.println(min);

    }
}
