package XuanZi.CH06.循环结构二;
//根据输入的数计算加法

import java.util.Scanner;

public class XuanZi12 {
    public static void main(String[] args) {
        int i, j;
        Scanner input = new Scanner(System.in);
        System.out.print("请输入一个值");
        int val = input.nextInt();
        //表达式1中可以声明多个同一类型的值并赋值，用“，”隔开
        for (i = 0, j = val; i <= val; i++, j--) {
            //表达式3可以是用“，”隔开的多个表达式，运算顺序从左到右
            System.out.println(i + " + " + j + " = " + (i + j));
        }
    }
}