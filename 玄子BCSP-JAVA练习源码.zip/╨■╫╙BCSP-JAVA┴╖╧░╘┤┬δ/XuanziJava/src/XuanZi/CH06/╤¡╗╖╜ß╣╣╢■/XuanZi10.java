package XuanZi.CH06.循环结构二;

import java.util.Scanner;

public class XuanZi10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int name = 0;
        String birthday = "";
        int ji = 0;
        for (int i = 1; i <= 3; i++) {
            System.out.println("请输入会员号：");
            if (input.hasNextInt()) {
                name = input.nextInt();
            } else {
                System.out.println("请输入数字");
                break;
            }


            System.out.println("请输入会员生日：");
            birthday = input.next();
            System.out.println("请输入会员积分：");
            ji = input.nextInt();


            if (name < 1000 || name > 9999) {
                continue;
            }
            System.out.println(name + "\n" + birthday + "\n" + ji + " ");


        }

        System.out.println("结束");

    }
}