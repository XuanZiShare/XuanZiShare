package XuanZi.CH06.循环结构二;

public class XUanZi06 {
    public static void main(String[] args) {


        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
            System.out.println(i);
            if (sum > 20) {
                break;
            }
        }
        System.out.println("当前和是" + sum);

    }
}