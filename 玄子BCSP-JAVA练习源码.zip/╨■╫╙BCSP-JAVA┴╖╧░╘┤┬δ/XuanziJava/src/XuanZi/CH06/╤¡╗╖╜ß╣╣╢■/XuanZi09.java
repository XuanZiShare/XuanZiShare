package XuanZi.CH06.循环结构二;

///continue语句的使用
public class XuanZi09 {
    public static void main(String[] args) {
        int sum = 0;
        int sum2 = 0;
        for (int i = 1; i <= 100; i++) {
            if (i % 2 == 1) {
//                奇数不要
                continue;
            }
            sum += i;
            //偶数
        }
        for (int i = 0; i <= 100; i++) {
            if (i % 2 == 0) {
//                偶数不要
                continue;
            }
            sum2 += i;
            //奇数
        }
        System.out.println(sum);
        System.out.println(sum2);
    }
}
