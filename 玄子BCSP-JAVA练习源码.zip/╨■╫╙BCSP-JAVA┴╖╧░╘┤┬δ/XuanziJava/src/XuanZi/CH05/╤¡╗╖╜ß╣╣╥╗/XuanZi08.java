package XuanZi.CH05.循环结构一;
//循环询问商品价格
import java.util.Scanner;

public class XuanZi08 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String jiXu = "Y";
        while (jiXu.equals("Y") || jiXu.equals("y")) {
            System.out.println("1.T恤\t2.网球鞋\t3.网球拍");
            System.out.println("请选择购买的商品:");
            int sp = input.nextInt();
            switch (sp) {
                case 1:
                    System.out.println("T恤衫200元");
                    break;
                case 2:
                    System.out.println("网球鞋300元");
                    break;
                case 3:
                    System.out.println("网球拍10元");
                    break;
                default:
                    System.out.println("请输入正确的数字");
                    break;
            }

            System.out.println("是否继续，Y/N");
            jiXu = input.next();
        }
    }
}
