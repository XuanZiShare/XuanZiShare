package XuanZi.CH05.循环结构一;
//循环询问

import java.util.Scanner;

public class XuanZi04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("吃了吗？");
        String jie1 = input.next();
        while (jie1.equals("没")) {
            System.out.println("那就吃");
            System.out.println("吃了吗？");
            jie1 = input.next();
        }
        System.out.println("吃不了兜着走");
    }
}
