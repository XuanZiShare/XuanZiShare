package XuanZi.CH05.循环结构一;
//循环判断
public class XuanZi01 {
    public static void main(String[] args) {
        int ciShu =1;
        while (ciShu <=50){
            System.out.println(ciShu++);
        }
    }
}
