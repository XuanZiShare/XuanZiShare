package XuanZi.CH05.循环结构一;
//循环增加
public class XuanZi03 {
    public static void main(String[] args) {
        int year = 2012;
        double pepele = 25;
        while (pepele <= 100) {
            year++;
            pepele *= 1.25;
            System.out.println(year + "年" + pepele + "万人");
        }

    }
}
