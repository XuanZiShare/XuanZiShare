package XuanZi.CH05.循环结构一;

import java.util.Scanner;

public class XuanZi16 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("1.菜单一");
        System.out.println("2.菜单二");
        System.out.println("3.菜单三");
        System.out.println("4.菜单四");


        //循环询问正确退出
        //错误继续询问\


        int num;

        do {
            System.out.println("请输入数字：");
            num = input.nextInt();

        } while (num > 4 || num < 1);
        switch (num) {
            case 1:
                System.out.println("菜单一");
                break;
            case 2:
                System.out.println("菜单二");
                break;
            case 3:
                System.out.println("菜单三");
                break;
            case 4:
                System.out.println("菜单四");
                break;
        }
//        System.out.println("菜单" + num);


//
//        while(num <4||num<1){
//
//            if (num!=4||num!=3||num!=2||num!=1){
//                System.out.println("输入错误");
//            }else{
//                System.out.println("菜单"+num);
//            }
//
//        }
//        //使用do while 结构 加上do循环结构
//
//        if (nmu！4){
//
//
//        while(num<=4||num<1){
//            System.out.println("输入正确菜单"+num);
//        }
//        }
//        System.out.println("");
//
//        if (num<4||num<1) {
//
//        }
//

    }
}
