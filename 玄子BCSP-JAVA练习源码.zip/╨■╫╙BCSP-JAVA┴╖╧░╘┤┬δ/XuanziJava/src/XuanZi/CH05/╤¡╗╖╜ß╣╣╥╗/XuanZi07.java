package XuanZi.CH05.循环结构一;
//100以内奇数和跟偶数和
public class XuanZi07 {
    public static void main(String[] args) {
        int num = 0;
        int jiShu = 0;
        int ouShu = 0;
        while (num <= 100) {
            if (num % 2 == 0) {
                ouShu += num;
            } else {
                jiShu += num;
            }
            num++;
        }

        System.out.println(jiShu + " " + ouShu);
    }
}
