package XuanZi.CH05.循环结构一;
//循环询问
import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("是否合格？");
        String jie1 = input.next();
        while (jie1.equals("否")){
            System.out.println("上午学习教材，下午学习编程");
            System.out.println("是否合格？");
             jie1 = input.next();
        }
        System.out.println("学习结束");
    }
}
