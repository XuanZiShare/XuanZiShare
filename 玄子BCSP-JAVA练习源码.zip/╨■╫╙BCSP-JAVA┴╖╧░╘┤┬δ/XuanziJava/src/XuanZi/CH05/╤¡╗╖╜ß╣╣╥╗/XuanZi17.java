package XuanZi.CH05.循环结构一;

import java.util.Scanner;

public class XuanZi17 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

    }
}
