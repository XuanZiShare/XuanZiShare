package XuanZi.CH05.循环结构一;

import java.util.Scanner;

public class XuanZi15 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double sheShi = 0;
        double huaShi = 0;
        System.out.println("摄氏温度\t:\t华氏温度");
        int tiao = 0;
        while (sheShi <= 250 && tiao < 10) {

            huaShi = sheShi * 9 / 0.5 + 32;
            System.out.println(sheShi + "\t:" + "\t" + huaShi);
            sheShi += 20;
            tiao++;
        }

    }
}

