package XuanZi.CH05.循环结构一;
//二进制转换十进制
import java.util.Scanner;

public class XuanZi11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //先判断有几位数
        //输入数*输入位数减去1的平方
        //转换后数值相加
        //输出最终结果
        System.out.println("请输入二进制数字：");
        int erjinzhi=input.nextInt();

        int shijinzhi=0,p=0;
        while(erjinzhi!=0)
        {
            shijinzhi+=((erjinzhi%10)*Math.pow(2,p));
            erjinzhi=erjinzhi/10;
            p++;
        }
        System.out.println(shijinzhi);
    }
}

