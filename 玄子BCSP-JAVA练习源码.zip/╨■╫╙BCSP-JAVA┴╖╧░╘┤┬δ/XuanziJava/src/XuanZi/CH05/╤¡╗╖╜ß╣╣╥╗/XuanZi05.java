package XuanZi.CH05.循环结构一;
//100以内偶数之和
public class XuanZi05 {
    public static void main(String[] args) {
        int i = 0;
        int j = 0;
        while(i<=100){
            j=j+i;
            i+=2;
        }
        System.out.println(j);



    }

}
