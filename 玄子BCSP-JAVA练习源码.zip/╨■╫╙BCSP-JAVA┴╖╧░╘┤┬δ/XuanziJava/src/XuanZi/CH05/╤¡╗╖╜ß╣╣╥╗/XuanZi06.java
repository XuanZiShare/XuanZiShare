package XuanZi.CH05.循环结构一;
//100以内奇数之和
public class XuanZi06 {
    public static void main(String[] args) {
        int i = 1;
        int j = 0;
        while (i <= 100) {
            j = j + i;
            i += 2;
        }
        System.out.println(j);


    }
}