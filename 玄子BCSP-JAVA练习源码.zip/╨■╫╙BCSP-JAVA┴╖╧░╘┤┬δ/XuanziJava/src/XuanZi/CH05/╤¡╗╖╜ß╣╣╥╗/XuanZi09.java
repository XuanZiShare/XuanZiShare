package XuanZi.CH05.循环结构一;
//循环相加商品价格
import java.util.Scanner;

public class XuanZi09 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String jiXu = "Y";
        double zongJian=0;
        while (jiXu.equals("Y") || jiXu.equals("y")) {
            System.out.println("1.T恤\t2.网球鞋\t\t3.网球拍");
            System.out.print("请选择购买的商品:");
            int sp = input.nextInt();
            System.out.print("请输入购买的数量：");
            int num = input.nextInt();

            switch (sp) {
                case 1:
                    System.out.print("T恤衫200元\t");
                    System.out.print("您购买了"+num+"个");
                    System.out.println("总价："+num*200);
                    zongJian+=num*200;
                    break;
                case 2:
                    System.out.print("网球鞋300元\t");
                    System.out.print("您购买了"+num+"个");
                    System.out.println("总价："+num*300);
                    zongJian+=num*300;
                    break;
                case 3:
                    System.out.print("网球拍10元\t");
                    System.out.print("您购买了"+num+"个");
                    System.out.println("总价："+num*10);
                    zongJian+=num*10;
                    break;
                default:
                    System.out.println("！！！！！！！！！！！！");
                    System.out.println("！！请输入正确的数字！！");
                    System.out.println("！！！！！！！！！！！！");
                    break;
            }

            System.out.print("是否继续（Y/N）：");
            jiXu = input.next();
        }
        System.out.println("折扣：0.8");
        System.out.println("总金额："+zongJian);
        System.out.print("实付金额：");
        double money = input.nextDouble();
        System.out.println("找钱："+(money-zongJian));

    }
}
