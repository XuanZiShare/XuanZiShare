package XuanZi.CH05.循环结构一;
//基础do while 结构

import java.util.Scanner;

public class XuanZi13 {
    public static void main(String[] args) {

        Scanner inout = new Scanner(System.in);
        String jie1;

        do {
            System.out.println("吃了没？（y/n）");
            jie1 = inout.next();
        } while ("n".equals(jie1));

        System.out.println("吃不了兜着走");
    }
}