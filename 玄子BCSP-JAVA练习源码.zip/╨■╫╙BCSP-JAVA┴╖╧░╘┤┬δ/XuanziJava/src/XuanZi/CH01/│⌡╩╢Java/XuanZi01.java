package XuanZi.CH01.初识Java;

public class XuanZi01 {
    public static void main(String[] args) {

        System.out.println("此章没有代码内容,详讲请看ACCP，思维导图-下载jdk，配置环境变量等。");
    }
}
