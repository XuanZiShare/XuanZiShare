package XuanZi.CH14.带参数的方法.G学生;

public class XuanZi01 {
    String name;
    int xueHao;
    int age;
    Double score;

    @Override
    public String toString() {
        return "XuanZi01{" +
                "name='" + name + '\'' +
                ", xueHao=" + xueHao +
                ", age=" + age +
                ", score=" + score +
                '}';
    }

}
