package XuanZi.CH14.带参数的方法.G学生;

public class Test {
    public static void main(String[] args) {
        XuanZi01 student = new XuanZi01();
        student.age = 18;
        student.name = "玄子";
        student.xueHao = 1122312;
        student.score = 90.0;
//添加学生一的对象属性
        XuanZi01 student2 = new XuanZi01();
        student2.age = 19;
        student2.name = "玄子2";
        student2.xueHao = 1122222312;
        student2.score = 90.2220;
//添加学生二的对象属性

        XuanZi02 teacher = new XuanZi02();
//创建老师对象
        teacher.addStudent(student);
//        添加学生1信息
        teacher.addStudent(student2);
        //        添加学生2信息
        teacher.showStudent();

    }
}
