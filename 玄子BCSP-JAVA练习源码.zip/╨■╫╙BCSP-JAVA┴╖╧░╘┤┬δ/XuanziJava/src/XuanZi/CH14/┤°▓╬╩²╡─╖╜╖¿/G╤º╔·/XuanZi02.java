package XuanZi.CH14.带参数的方法.G学生;

public class XuanZi02 {
    XuanZi01[] students = new XuanZi01[31];

    public void addStudent(XuanZi01 student) {
        for (int i = 0; i < students.length; i++) {
            if (students[i] == null) {
                students[i] = student;
                break;
            }
        }
    }

    public void showStudent() {
        for (int i = 0; i < students.length; i++) {
            if (students[i] != null) {
                System.out.println(students[i].toString());
            }
        }
    }
}
