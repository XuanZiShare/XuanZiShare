package XuanZi.CH14.带参数的方法.C找人;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 find = new XuanZi01();
//        find.find("玄子");
//        find.find("玄子1");
        find.find2("玄子2", 2, 4);
        System.out.println(find.found);
    }
}
