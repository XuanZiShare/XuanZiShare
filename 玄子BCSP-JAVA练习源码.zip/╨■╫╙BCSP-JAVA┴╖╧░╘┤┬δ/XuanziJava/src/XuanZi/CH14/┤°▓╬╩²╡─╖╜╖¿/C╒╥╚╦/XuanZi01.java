package XuanZi.CH14.带参数的方法.C找人;

public class XuanZi01 {
    String[] names = {"C", "A", "B", "C", "A", "玄子1"};
    boolean found = false;

    public void find(String name) {

        for (int i = 0; i < names.length; i++) {
            if (names[i] == name) {
                found = true;
                break;
            }

        }
    }

    public void find2(String name, int start, int end) {

        for (int i = start - 1; i < end; i++) {
            if (names[i] == name) {
                found = true;
                break;
            }

        }
    }
}
