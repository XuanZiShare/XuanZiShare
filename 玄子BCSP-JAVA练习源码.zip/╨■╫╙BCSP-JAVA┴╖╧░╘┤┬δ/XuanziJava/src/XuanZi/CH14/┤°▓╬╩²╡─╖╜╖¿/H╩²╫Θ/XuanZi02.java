package XuanZi.CH14.带参数的方法.H数组;

public class XuanZi02 {
    public static void main(String[] args) {
        Xuanzi01 str = new Xuanzi01();

        String[] names = {"玄子", "玉玉诏", "张三", "李四", "王五"};
//  声明数组

        str.sortname(names);
// 调用排序方法
        
        for (int i = 0; i < names.length; i++) {
            System.out.println(names[i]);
        }
//        输出排序结果
    }
}
