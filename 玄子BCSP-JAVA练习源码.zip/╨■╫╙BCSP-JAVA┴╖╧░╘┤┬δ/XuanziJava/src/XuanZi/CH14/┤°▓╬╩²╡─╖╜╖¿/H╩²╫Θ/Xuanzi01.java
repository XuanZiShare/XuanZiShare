package XuanZi.CH14.带参数的方法.H数组;


import java.util.Arrays;

public class Xuanzi01 {

    public void sortname(String[] names) {
        //此处需要接收数组 [] 形参
        Arrays.sort(names);

//        导入数组排序
    }
}
