package XuanZi.CH14.带参数的方法.B名字;

public class XuanZi01 {
    String dan;
    String[] names = new String[30];

    public void getName(String name) {
        for (int i = 0; i < name.length(); i++) {
            if (names[i] == null) {
                names[i] = name;
                break;
            }
        }

    }

//    public void updateName() {
//        int xb = 0;
//        for (int i = 0; i < name.length(); i++) {
//            if (names[i] == null) {
//                xb = i;
//                names[i] = name;
//                break;
//            }
//
//        }
//
//    }

    public void Show() {
        for (int i = 0; i < names.length; i++) {
            System.out.println(names[i]);
        }
    }
    //增


    public void getName1(String name) {
        int xb = 0;
        for (int i = 0; i < name.length(); i++) {
            if (names[i] == null) {
                xb = i;
                names[i] = name;
                break;
            }

        }


    }


}

