package XuanZi.CH14.带参数的方法.B名字;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 name = new XuanZi01();
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < 30; i++) {
            System.out.println("请输入第" + i + "位同学的名字");
            name.getName(input.next());
        }


        name.Show();
    }
}
