package XuanZi.CH14.带参数的方法.E增删改查;

public class XuanZi01 {
    String[] names = new String[31];
    //改
    boolean exists = false;

    public void add(String name) {
        for (int i = 0; i < names.length; i++) {
            if (names[i] == null) {

                names[i] = name;
                break;
            }
        }
    }
    //增

    public void del(String name) {
        for (int i = 0; i < names.length; i++) {
            if (name.equals(name)) {

                names[i] = null;
                break;
            }
        }
    }

    //删
    public void upda(String oldname, String newname) {
        for (int i = 0; i < names.length; i++) {
            if (oldname.equals(oldname)) {

                names[i] = newname;
                break;
            }
        }
    }
    //改

    public void search(String name) {

        for (int i = 0; i < names.length; i++) {
            if (name.equals(name)) {
                exists = true;
                break;
            }
        }
    }
    //查


    public void Show() {
        for (int i = 0; i < names.length; i++) {
            if (names[i] != null) {
                System.out.println(names[i]);
            }

        }
    }
}
