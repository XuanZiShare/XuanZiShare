package XuanZi.CH14.带参数的方法.E增删改查;


import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 wen = new XuanZi01();
        Scanner input = new Scanner(System.in);
        String y;
        do {
            System.out.println("请输入名字");
            wen.add(input.next());
            System.out.println("请输入y/n");
            y = input.next();
        } while ("y".equals(y));
        wen.Show();
        //增加的
        System.out.println("请输入删除的数据");
        wen.del(input.next());
        wen.Show();
        //删除
        System.out.println("请输入要将哪个数修改成哪个数");
        wen.upda(input.next(), input.next());
        wen.Show();
        //改
        System.out.println("请输入要查找的数据");
        wen.search(input.next());
        System.out.println(wen.exists);
        //查
    }
}
