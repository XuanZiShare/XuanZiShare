package XuanZi.CH14.带参数的方法.A信息;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 xinXi = new XuanZi01();

        xinXi.ZhaZhi("玄子", 18);

    }
}
