package XuanZi.CH14.带参数的方法.A信息;

public class XuanZi01 {
    public void ZhaZhi(String name, int age) {
        System.out.println(name + age);

    }

}
