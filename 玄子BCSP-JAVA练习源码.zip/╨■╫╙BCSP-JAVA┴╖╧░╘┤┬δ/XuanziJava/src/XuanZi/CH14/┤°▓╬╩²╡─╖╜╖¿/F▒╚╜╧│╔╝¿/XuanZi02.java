package XuanZi.CH14.带参数的方法.F比较成绩;

public class XuanZi02 {
    public static void main(String[] args) {
        XuanZi01 cj = new XuanZi01();
        int[] sums = {1, 2, 3, 4, 5, 6, 7, 8};
        System.out.println(cj.Max(sums));
        System.out.println(cj.Min(sums));
        System.out.println(cj.avg(sums));
    }
}
