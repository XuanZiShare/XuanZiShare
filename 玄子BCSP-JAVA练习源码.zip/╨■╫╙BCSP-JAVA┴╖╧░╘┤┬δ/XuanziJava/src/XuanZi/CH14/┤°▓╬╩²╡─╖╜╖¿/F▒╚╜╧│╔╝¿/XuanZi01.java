package XuanZi.CH14.带参数的方法.F比较成绩;

public class XuanZi01 {

    public int Max(int[] sum) {
        //此处需要接收形参 []
        int max = 0;
        for (int i = 0; i < sum.length; i++) {
            if (sum[i] > max) {
                max = sum[i];
            }
        }
        return max;
    }
//    最大值


    public int Min(int[] sum) {
        //此处需要接收形参 []
        int min = 0;
        for (int i = 0; i < sum.length; i++) {
            if (sum[i] < min) {
                min = sum[i];
            }
        }
        return min;
    }
//    最小值


    public Double avg(int[] sum) {
        //此处需要接收形参 []
        int summ = 0;
        for (int i = 0; i < sum.length; i++) {
            summ += sum[i];
            //计算总和
        }
        double avg = summ / sum.length;
//        计算平均分
        return avg;
//        返回平均分
    }
}
