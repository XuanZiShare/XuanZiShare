package XuanZi.CH09.循环结构进阶;
//打印菱形

import java.util.Scanner;

public class XuanZi03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        //打印多少空格 等于 总行数减去第几行
        //打印多少* 等于2乘以第几行减去一;
        System.out.print("请输入菱形的行数");
        int row = input.nextInt();
        //菱形的行数只能是奇数
        while ((row % 2 == 0)) {
            System.out.println("只能输入奇数,请重写输入");
            System.out.print("请输入菱形的行数");
            row = input.nextInt();
        }
        //打印上半部分 只有一半 所以行数除以2  加一因为行数是奇数
        int n = (row / 2) + 1;
        //先打印上半部分
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        //在打印下半部分
        int nn = n - 1;
        //下半部分的行数比是上半部分一半减一
        for (int i = nn; i >= 1; i--) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
