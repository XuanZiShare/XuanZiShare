package XuanZi.CH09.循环结构进阶;

import java.util.Scanner;

public class TestOneDay {
    public static void main(String[] args) {
        String answer;
        //是否继续执行程序
        do {
            Scanner input = new Scanner(System.in);
            OneDay day = new OneDay();
            //创建对象 名字为day
            System.out.println("请选择要执行的程序");
            System.out.println("1.升序和降序");
            System.out.println("2.循环晋级案例");
            System.out.println("3.九九乘法表");
            System.out.println("4.正三角形");
            System.out.println("5.倒三角形");
            System.out.println("6.打印菱形");
            System.out.print("请选择:");
            int num = input.nextInt();
            //接收选择的数字
            switch (num) {
                case 1:
                    day.UpAndDown();
                    //升序和降序
                    break;
                case 2:
                    day.promotion();
                    break;
                case 3:
                    day.multiplicationTable();
                    break;
                case 4:
                    day.PositiveTriangle();
                    break;
                case 5:
                    day.invertedTriangle();
                    break;
                case 6:
                    day.lozenge();
                    break;
                default:
                    System.out.println("没乱选，没有");
                    break;
            }
            System.out.print("\n是否继续(y/n):");
            answer = input.next();
        } while ("y".equalsIgnoreCase(answer));
        //equalsIgnoreCase与equals性质差不多，不同的是equalsIgnoreCase不区分大小写
        System.out.println("程序退出，谢谢");
    }
}
