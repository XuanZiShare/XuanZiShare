package XuanZi.CH09.循环结构进阶;

import java.util.Scanner;

public class XuanZi04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("显示等腰三角形");
        System.out.print("请输入三角形行数:");
        int row = input.nextInt();
        //接收用户输入行数
        for (int i = 1; i <= row; i++) {

            for (int j = 1; j <= row - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
