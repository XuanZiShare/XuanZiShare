package XuanZi.CH09.循环结构进阶;

import java.util.Scanner;

public class XuanZi01 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] nums = new int[5];
        //定义一个数组   用来储存随机数
        for (int i = 0; i < nums.length; i++) {
            nums[i] = (int) (Math.random() * (9000) + 1000);
            //循环五次 四位数的随机数  储存到数组里边
        }
        int cardNum;
        int xuan;
        String shifou = "";
        //是否继续
        String zcyhm = "";
//        注册的账号

        String zcmm = "";
        //注册的密码
        String dlyhm;
        //登录的账号
        String dlmm = "";
        //登陆的密码
        boolean zhengChangRen = true;
        //  判断输入错误了三次就停止

        int random = 0;
        //随机数 命名赋值
        do {
            System.out.println("***********欢迎进入奖客富翁系统**********");
            System.out.println(" 1.注册");
            System.out.println(" 2.登录");
            System.out.println(" 3.抽奖");
            System.out.println("*************************************");
            System.out.println("请选择菜单");
            if (input.hasNextInt()) {
                //用来判断输入的是否是整数
                xuan = input.nextInt();
                switch (xuan) {
                    case 1:
                        System.out.println("奖客富翁系统>注册");
                        System.out.println("请填写个人注册信息");
                        System.out.print("用户名:");
                        zcyhm = input.next();
                        //接收注册的账号
                        System.out.print("密码:");
                        zcmm = input.next();
                        //接收注册的密码
                        random = (int) (Math.random() * 9000) + 1000;
                        //输出一个随机的四位数的会员号

                        System.out.println("注册成功，请记好您的会员卡号");
                        System.out.println("用户名\t密码\t\t会员卡号");
                        System.out.println(zcyhm + "\t\t" + zcmm + "\t\t" + random);
                        break;
                    case 2:
                        System.out.println("奖客富翁系统>登录");
                        for (int i = 1; i <= 3; i++) {
                            //循环输入账号密码  输入成功就停止循环
                            System.out.println("请输入用户名");
                            dlyhm = input.next();
                            //接收 登陆的账号
                            System.out.println("请输入密码");
                            dlmm = input.next();
                            //接收登陆的密码

                            if (zcyhm.equals(dlyhm) && zcmm.equals(dlmm)) {
                                //判断登陆的账号密码 是否和 注册的一样
                                System.out.println("登陆成功");
                                break;
                            } else {
                                //如果登陆的账号密码跟注册的账号密码不一致  则登陆失败 重新输入 最多可以输入3次
                                System.out.println("登陆失败");
                                System.out.println("您还有" + (3 - i) + "次机会");
                                if (i == 3) {
                                    //如果输入了三次都是错误 则退出系统
                                    zhengChangRen = false;
                                    System.out.println("三次输入均未错误");
                                    break;
                                }
                            }
                        }
                        break;
                    case 3:
                        System.out.println("奖客富翁系统>抽奖");
                        System.out.println("请输入一个四位数的会员号");
                        cardNum = input.nextInt();

                        for (int i = 0; i < nums.length; i++) {
                            System.out.println(nums[i] + "\t");
                        }
                        for (int i = 0; i < nums.length; i++) {
                            if (nums[i] == cardNum) {
                                System.out.println("中了五百万");
                                break;
                            } else {
                                System.out.println("您没有中奖");
                                break;
                            }
                        }
                        break;
                    default:
                        System.out.println("请输入1~3之间的整数");
                        break;
                }
                if (zhengChangRen) {
                    //判断账号密码是否输入正确
                    System.out.println("继续吗？(Y/N)");
                    shifou = input.next();
                    //询问是否继续
                } else {
                    //如果输入的账号密码错误则退出系统
                    break;
                }
            } else {
                //判断 输入的菜单 是否是整数
                System.out.println("您的输入有误");
            }
        } while ("Y".equals(shifou) || "y".equals(shifou));
        //如果输入的是Y就继续循环
    }
}
