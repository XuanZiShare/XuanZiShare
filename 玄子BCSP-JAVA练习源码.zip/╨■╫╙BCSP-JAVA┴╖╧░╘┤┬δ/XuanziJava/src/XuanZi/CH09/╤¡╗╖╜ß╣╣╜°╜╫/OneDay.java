package XuanZi.CH09.循环结构进阶;

import java.util.Arrays;
import java.util.Scanner;

public class OneDay {
    Scanner input = new Scanner(System.in);

    //升序和降序
    public void UpAndDown() {
        int[] a = new int[]{3, 5, 9, 8, 7, 2, 8};
        //随机定义一个无序的数组
        System.out.println("原数组显示");
        //显示数组
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        Arrays.sort(a);
        //数字升序方法
        System.out.println("\n升序数组显示");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println("\n数组降序显示");
        for (int i = a.length - 1; i >= 0; i--) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[a.length - i - 1] + " ");
        }
    }

    //循环晋级案例
    public void promotion() {
        System.out.println("循环晋级显示");
        int ju = 1;
        //局数
        int count = 0;
        //份数超过八十的人
        boolean iscontinue;
        //判断继续下一局是否正确
        System.out.println("青鸟迷你游戏平台>游戏晋级");
        do {
            System.out.print("您正在玩第" + ju + "局,成绩为:");
            int score = input.nextInt();
            //录入成绩
            if (score > 80) {
                count++;
            }
            ju++;
            if (ju > 5) {
                System.out.println("游戏结束");
                break;
            }
            System.out.print("继续下一局吗(y/n):");
            String answer = input.next();
            //是否下一局;
            //使用正则表达式判断输入的是否为Y/N
            //可以忽略，只是判断输入的是否为Y或N
            iscontinue = answer.matches("(y|Y|n|N){1}");
            while (!iscontinue) {
                System.out.println("输入错误，请重新输入");
                System.out.print("继续下一局吗(y/n):");
                answer = input.next();
                iscontinue = answer.matches("(y|Y|n|N){1}");
            }
            if (ju < 5 && "n".equalsIgnoreCase(answer)) {
                System.out.println("您已经中途退出游戏,不能晋级");
                System.out.println("对不起，您未能晋级，继续加油啊！");
                break;
            } else {

                System.out.println("进入下一局");

            }
        } while (ju <= 5);
        if ((count / 5.0) >= 0.8) {
            System.out.println("一级");
        } else if ((count / 5.0) >= 0.6) {
            System.out.println("二级");
        } else {
            System.out.println("未通过");
        }
    }

    //九九乘法表
    public void multiplicationTable() {
        System.out.println("九九乘法表显示");
        for (int i = 0; i <= 9; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(i + "*" + j + "=" + (j * i) + " ");
            }
            System.out.println();
        }
    }

    //正三角形
    public void PositiveTriangle() {
        System.out.println("显示正三角形");
        System.out.print("请输入行数:");
        int row = input.nextInt();
        for (int i = 1; i <= row; i++) {
            for (int j = 1; j <= row - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }

    //倒三角形
    public void invertedTriangle() {
        System.out.println("显示正三角形");
        System.out.print("请输入行数:");
        int row = input.nextInt();
        for (int i = row; i >= 1; i--) {
            for (int j = 1; j <= row - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

    }

    //打印菱形
    public void lozenge() {
        //打印多少空格 等于 总行数减去第几行
        //打印多少* 等于2乘以第几行减去一;
        System.out.print("请输入菱形的行数");
        int row = input.nextInt();
        //菱形的行数只能是奇数
        while ((row % 2 == 0)) {
            System.out.println("只能输入奇数,请重写输入");
            System.out.print("请输入菱形的行数");
            row = input.nextInt();
        }
        //打印上半部分 只有一半 所以行数除以2  加一因为行数是奇数
        int n = (row / 2) + 1;
        //先打印上半部分
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        //在打印下半部分
        int nn = n - 1;
        //下半部分的行数比是上半部分一半减一
        for (int i = nn; i >= 1; i--) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
