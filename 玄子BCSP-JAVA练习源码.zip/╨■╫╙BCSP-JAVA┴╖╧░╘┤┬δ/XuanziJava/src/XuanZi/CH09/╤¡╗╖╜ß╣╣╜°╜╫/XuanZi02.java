package XuanZi.CH09.循环结构进阶;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("请输入行数：");
        int row = input.nextInt();
        for (int i = 1; i <= row; i++) {
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

    }
}
