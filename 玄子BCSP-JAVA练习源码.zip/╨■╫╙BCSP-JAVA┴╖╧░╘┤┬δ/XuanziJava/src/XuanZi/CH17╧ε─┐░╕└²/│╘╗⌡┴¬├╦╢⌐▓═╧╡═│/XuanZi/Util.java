package XuanZi.CH17项目案例.吃货联盟订餐系统.XuanZi;

import java.util.Scanner;

public class Util {
    CaiDan caiDan = new CaiDan();
    DingDan dingDan = new DingDan();
    Scanner input = new Scanner(System.in);

    //创建对象
    public void ChuShiHuaDingDan() {
        //初始化订单，初始化两次订单
        dingDan.names[0] = "玄子";
        dingDan.caiPinMings[0] = caiDan.names[0];
        dingDan.shiJias[0] = caiDan.prices[0];
        dingDan.fenShus[0] = 13;
        dingDan.diZhis[0] = "漯河";
        dingDan.zongJinErs[0] = (dingDan.shiJias[0] * dingDan.fenShus[0]);
        dingDan.zhuangTais[0] = "已签收";


        dingDan.names[1] = "玉玉诏";
        dingDan.caiPinMings[1] = caiDan.names[1];
        dingDan.shiJias[1] = caiDan.prices[1];
        dingDan.fenShus[1] = 30;
        dingDan.diZhis[1] = "郑州";
        dingDan.zongJinErs[1] = (dingDan.shiJias[1] * dingDan.fenShus[1]);
        dingDan.zhuangTais[1] = "未签收";
    }

    public void ChuShiHuaCaigDan() {
        //初始化菜单  四个菜  名字  单价  点赞
        caiDan.names[0] = "蒜薹炒肉";
        caiDan.dainZans[0] = 0;
        caiDan.prices[0] = 12;

        caiDan.names[1] = "鱼香肉丝";
        caiDan.dainZans[1] = 0;
        caiDan.prices[1] = 16;

        caiDan.names[2] = "麻婆豆腐";
        caiDan.dainZans[2] = 0;
        caiDan.prices[2] = 12;

        caiDan.names[3] = "胡辣汤";
        caiDan.dainZans[3] = 0;
        caiDan.prices[3] = 6;

    }

    public void ZhuCaiDan() {
        ChuShiHuaCaigDan();
        ChuShiHuaDingDan();
        int jie1;
        //初始化主菜单
        do {
            System.out.println("欢迎使用吃货联盟订餐系统");
            System.out.println("***********************");
            System.out.println("1.我要订餐");
            System.out.println("2.查看餐袋");
            System.out.println("3.签收订单");
            System.out.println("4.删除订单");
            System.out.println("5.我要点赞");
            System.out.println("6.退出系统");
            System.out.println("************************");
            System.out.print("请选择：");
            int jie = input.nextInt();
            switch (jie) {
                case 1:
                    ZhuCaiDan1();
                    break;
                case 2:
                    ZhuCaiDan2();
                    break;
                case 3:
                    ZhuCaiDan3();
                    break;
                case 4:
                    ZhuCaiDan4();
                    break;
                case 5:
                    ZhuCaiDan5();
                    break;
                case 6:
                default:
                    System.out.print("输入2退出，");
                    break;
            }
            System.out.println("输入0返回");
            jie1 = input.nextInt();
        } while (jie1 == 0);
        System.out.println("已退出订餐系统");

    }

    public void ZhuCaiDan1() {
        int canFei = 0;
        System.out.println("***我要订餐***");
        System.out.println("请输入订餐人姓名：");
        String jie = input.next();
        dingDan.names[2] = jie;
        System.out.println("序号\t" + "菜名\t" + "单价\t" + "点赞数\t");
        for (int i = 0; i < caiDan.names.length; i++) {
            System.out.println((i + 1) + "\t" + caiDan.names[i] + "\t" + caiDan.prices[i] + "\t" + caiDan.dainZans[i]);
        }
        //展示菜单
        System.out.println("请选择您要点的菜品编号：");
        int jie1 = input.nextInt();
        System.out.println("请选择您要的份数：");
        int jie2 = input.nextInt();
        dingDan.fenShus[2] = jie2;
        switch (jie1) {
            case 1:
            case 3:
                dingDan.caiPinMings[2] = caiDan.names[jie1 - 1];
                canFei = jie2 * 12;
                break;
            case 2:
                dingDan.caiPinMings[2] = caiDan.names[jie1 - 1];
                canFei = jie2 * 16;
                break;
            case 4:
                dingDan.caiPinMings[2] = caiDan.names[jie1 - 1];
                canFei = jie2 * 6;
                break;
        }
        //判断价格
        System.out.println("请选择您的送餐时间：(整点)");
        int jie3 = input.nextInt();
        dingDan.shiJias[2] = jie3;
        System.out.println("请选择您的送餐地址：");
        String jie4 = input.next();
        dingDan.diZhis[2] = jie4;
        System.out.println("送餐成功！");
        System.out.println("您定的是：" + dingDan.caiPinMings[2] + dingDan.fenShus[2] + "份");
        System.out.println("送餐时间：" + dingDan.shiJias[2]);
        int peiSongFei = jie2 >= 5 ? 0 : 5;
        //超过五份免配送费
        System.out.println("餐费：" + canFei + ",配送费" + peiSongFei + ",总计" + (canFei + peiSongFei) + "元。");
        dingDan.shiJias[2] = canFei + peiSongFei;
        dingDan.zhuangTais[2] = "未签收";

    }


    public void ZhuCaiDan2() {
        System.out.println("查看餐袋");
        System.out.println("序号" + "\t订餐人" + "\t餐品信息" + "\t送餐时间" + "\t送餐地址" + "\t总金额" + "\t订餐状态");
        for (int i = 0; i < dingDan.names.length; i++) {
            if (dingDan.names[i] != null) {
                System.out.println((i + 1) + "\t" + dingDan.names[i] + "\t" + dingDan.caiPinMings[i] + dingDan.fenShus[i] + "\t" + dingDan.shiJias[i] + "\t" + dingDan.diZhis[i] + "\t" + dingDan.shiJias[i] + "\t" + dingDan.zhuangTais[i]);
            }
        }
//        展示餐袋

    }

    public void ZhuCaiDan3() {
        //待修改     勿动！！！！
        System.out.println("***签收订单***");
        System.out.println("请选择您要签收的订单序号：");
        int jie = input.nextInt();
        switch (jie) {
            case 1:
                if (dingDan.zhuangTais[0] != null) {
                    dingDan.zhuangTais[0] = "已签收";
                } else if (dingDan.zhuangTais[0].equals("未签收")) {
                    System.out.println("签收成功");
                } else {
                    System.out.println("未查询到订单");
                }

                break;
            case 2:
                if (dingDan.zhuangTais[1] != null) {
                    dingDan.zhuangTais[1] = "已签收";
                } else if (dingDan.zhuangTais[0].equals("未签收")) {
                    System.out.println("签收成功");
                } else {
                    System.out.println("未查询到订单");
                }

                break;
            case 3:
                if (dingDan.zhuangTais[2] != null) {
                    dingDan.zhuangTais[2] = "已签收";
                } else if (dingDan.zhuangTais[0].equals("未签收")) {
                    System.out.println("签收成功");
                } else {
                    System.out.println("未查询到订单");
                }
                break;
            case 4:
            default:
                System.out.println("未查询到订单");
        }
        System.out.println("订单签收成功！");

    }

    public void ZhuCaiDan4() {
        System.out.println("***删除订单***");

        System.out.println("请选择您要删除的订单序号：");
        int jie = input.nextInt();
        switch (jie) {
            case 1:
                if ("已签收".equals(dingDan.zhuangTais[0])) {
                    System.out.println("删除成功");
                    dingDan.names[0] = null;
                } else {
                    System.out.println("订单未签收删除失败");
                }
                break;
            case 2:
                if ("已签收".equals(dingDan.zhuangTais[1])) {
                    System.out.println("删除成功");
                    dingDan.names[0] = null;
                } else {
                    System.out.println("订单未签收删除失败");
                }
                break;
            case 3:
                if ("已签收".equals(dingDan.zhuangTais[2])) {
                    System.out.println("删除成功");
                    dingDan.names[0] = null;
                } else {
                    System.out.println("订单未签收删除失败");
                }
                break;
            case 4:
            default:
                System.out.println("未查询到订单");
                break;
        }
//        把删除的订单替换掉
    }


    public void ZhuCaiDan5() {
        System.out.println("***我要点赞***");
        System.out.println("序号\t" + "菜名\t" + "单价\t" + "点赞数\t");
        for (int i = 0; i < caiDan.names.length; i++) {
            System.out.println((i + 1) + "\t" + caiDan.names[i] + "\t" + caiDan.prices[i] + "\t" + caiDan.dainZans[i]);
        }
        System.out.println("请选择您要点赞的菜品序号");
        int jie = input.nextInt();
        switch (jie) {
            case 1:
                caiDan.dainZans[0] += 1;
                System.out.println("点赞成功");
                break;
            case 2:
                caiDan.dainZans[1] += 1;
                System.out.println("点赞成功");
                break;
            case 3:
                caiDan.dainZans[2] += 1;
                System.out.println("点赞成功");
                break;
            default:
                System.out.println("未查询到序号点赞失败！");
                break;
        }

//商品点赞
    }


}
