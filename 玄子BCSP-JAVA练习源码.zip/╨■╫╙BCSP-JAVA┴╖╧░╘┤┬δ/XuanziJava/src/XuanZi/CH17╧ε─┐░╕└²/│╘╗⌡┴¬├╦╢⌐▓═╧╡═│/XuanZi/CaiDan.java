package XuanZi.CH17项目案例.吃货联盟订餐系统.XuanZi;

public class CaiDan {
    //  名字，价格，点赞
    String[] names = new String[4];
    //菜品的名字
    int[] prices = new int[4];
    //菜品的单价
    int[] dainZans = new int[4];
    //菜品的点赞数

}
