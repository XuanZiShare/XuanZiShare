package XuanZi.CH17项目案例.吃货联盟订餐系统.XuanZi;

public class DingDan {

    String[] names = new String[4];
    //订单人姓名
    String[] caiPinMings = new String[4];
    //点的菜名
    int[] shiJias = new int[4];
    //买的菜的单价
    String[] diZhis = new String[4];
    //地址
    String[] zhuangTais = new String[4];
    //状态
    double[] zongJinErs = new double[4];
    //    总金额
    int[] fenShus = new int[4];
//    菜品份数
}


