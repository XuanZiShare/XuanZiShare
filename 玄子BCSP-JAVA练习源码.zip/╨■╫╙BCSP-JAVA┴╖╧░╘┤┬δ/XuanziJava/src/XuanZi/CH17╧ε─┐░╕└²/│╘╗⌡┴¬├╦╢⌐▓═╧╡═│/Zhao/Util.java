package XuanZi.CH17项目案例.吃货联盟订餐系统.Zhao;

import java.util.Scanner;

public class Util {
    // 把Cai类引用到这里  定义一个对象
    Cai cai = new Cai();
    // 把DingDan类引用到这里  定义一个对象
    DingDan dingDan = new DingDan();
    //扫描器
    Scanner input = new Scanner(System.in);

    //初始化菜单
    public void chuShiHuaCai() {
        //给cai对象 的 属性赋值
        //数组下标
        cai.names[0] = "古法咖喱肉蟹";
        cai.names[1] = "古法咖喱大虾";
        cai.names[2] = "肉骨茶";
        cai.danJia[0] = 199;
        cai.danJia[1] = 99;
        cai.danJia[2] = 49;


    }

    //    初始化订单
//    public void chuShiHuaDingDan(){
//        int canFei=0;
//        double sum=0;
//        dingDan.names[0]="张俊豪";
//        dingDan.caiMings[0]=cai.names[0];
//        dingDan.fenShu[0]=33;
//        dingDan.diZhi[0]="北大青鸟七机房";
//        dingDan.shiJIan[0]="12:30";
//        sum=dingDan.sums[0]=cai.danJia[0]*dingDan.fenShu[0];
//        canFei =sum>50? 0 : 5;
//        sum=+sum+canFei;
//        System.out.println("总价格:"+sum);
//
//        dingDan.names[1]="李志军";
//        dingDan.caiMings[1]=cai.names[1];
//        dingDan.fenShu[1]=33;
//        dingDan.diZhi[1]="北大青鸟七机房";
//        dingDan.shiJIan[1]="12:30";
//       sum= dingDan.sums[1]=cai.danJia[1]*dingDan.fenShu[1];
//        canFei =sum>50? 0 : 5;
//        sum=+sum+canFei;
//        System.out.println("总价格:"+sum);
//    }
    //
    public void show() {
        //把初始化值 调用过来
        chuShiHuaCai();
//        chuShiHuaDingDan();
        //num  接收是否继续的值
        int num = 0;
        System.out.println("***欢迎使用吃货联盟****");
        do {
            System.out.println("1、我要订餐");
            System.out.println("2、查看餐袋");
            System.out.println("3、签收订单");
            System.out.println("4、删除订单");
            System.out.println("5、我要点赞");
            System.out.println("6、退出系统");
            System.out.println("请选择编号");
            int bianHao = input.nextInt();
            switch (bianHao) {
                case 1:
                    //订餐系统
                    fangWenDingDan();
                    showCanDai();
                    break;
                case 2:
                    // 查找餐袋
                    xianShiCaiDan();
                    showCanDai();
                    showCanDai();
                    break;
                case 3:
                    sign();
                    showCanDai();
                    break;
                case 4:
                    delete();
                    showCanDai();
                    break;
                case 5:
                    praise();
                    showCanDai();
                    break;
                case 6:
                    System.out.println("系统退出");
                    break;
                default:
                    break;

            }
            //
            if (bianHao == 6) {
                break;
            }
            System.out.println("输入0继续");
            //输入0 就会继续进行循环
            num = input.nextInt();
        } while (num == 0);

    }

    public void fangWenDingDan() {
        //订餐人的名字
        String name = "";
        // 菜品序号
        int num = 0;
        // 菜品
        String caiPin = "";
        //菜的单价
        double danJia = 0;
        //总金额
        double sum = 0;
        System.out.println("输入订餐人名称");
        name = input.next();
        System.out.println("请选择你要购买的菜品");
        System.out.println("1." + cai.names[0]);
        System.out.println("2." + cai.names[1]);
        System.out.println("3." + cai.names[2]);
        System.out.println("请输入序号");
        //接收客户输入的序号来判断客户要购买的哪一个菜
        num = input.nextInt();
        switch (num) {
            case 1:
                //把 之前给数组赋好的值 赋给caiPin和danJia
                caiPin = cai.names[0];
                danJia = cai.danJia[0];
                break;
            case 2:
                caiPin = cai.names[1];
                danJia = cai.danJia[1];
                break;
            case 3:
                caiPin = cai.names[2];
                danJia = cai.danJia[2];
                break;
            default:
                System.out.println("选择有误");
        }
        System.out.println("输入需要买几份");
        // 接收 需要购买几份
        int shu = input.nextInt();
        System.out.println("请输入送餐时间");
        //接收 送餐的时间
        String shiJian = input.next();
        System.out.println("请输入送餐地址");
        //接收需要送到哪里的地址
        String diZhi = input.next();
        //计算总金额
        double sum1 = shu * danJia;
        //  配送费  如果总金额大于50 就免五元的配送费
        //三目运算
        int canFei = sum1 >= 50 ? 0 : 5;
        // 在计算 到底有没有配送费
        sum = sum1 + canFei;
        for (int i = 0; i < dingDan.names.length; i++) {
            if (dingDan.caiMings[i] == null) {
                //把所有 输入进去的值 全部赋给订单类 里的数组
                // 人的姓名
                dingDan.names[i] = name;
                //购买的菜品
                dingDan.caiMings[i] = caiPin;
                //购买的数量
                dingDan.fenShu[i] = shu;
                // 配送的时间
                dingDan.shiJIan[i] = shiJian;
                // 地址
                dingDan.diZhi[i] = diZhi;
                // 总金额
                dingDan.sums[i] = sum;
                break;
            }
        }
        //进行输出
        System.out.println("订餐成功");
        System.out.println("您订购的是:" + caiPin + shu + "份");
        System.out.println("送餐时间是:" + shiJian);
        System.out.println("送餐地址是:" + diZhi);
        System.out.println("商品价格是:" + danJia + "配送费是:" + canFei + "总价格为:" + sum);
    }

    //显示菜单
    public void xianShiCaiDan() {
        //输出 序号  菜名  单价  点赞数
        System.out.println("序号\t菜名\t单价\t点赞数");
        for (int i = 0; i < cai.names.length; i++) {
            System.out.println((i + 1) + "\t" + cai.names[i] + "\t" + cai.danJia[i] + "\t" + cai.dianZan[i]);
        }
    }

    //展示 购买好的菜单
    public void showCanDai() {
        //查看餐袋
        System.out.println("****查看餐袋*****");
        System.out.println("序号\t订餐人\t\t菜名\t\t份数\t\t送餐地址\t总金额\t订单状态");

        for (int i = 0; i < dingDan.caiMings.length; i++) {
            // 布尔值判断是否送到   没有送到了就已完成  没有送到就未完成
            String zhuangTai = dingDan.zhuangTai[i] ? "0" : "1";
            if (dingDan.shiJIan[i] != null) {

                System.out.println((i + 1) + "\t" + dingDan.names[i] + "\t" + dingDan.caiMings[i] + "\t" + dingDan.fenShu[i] + "\t\t" + dingDan.diZhi[i] + "\t" + dingDan.sums[i] + "\t" + zhuangTai);
            }
        }
    }

    public void sign() {
        boolean q = false;
        int num = 0;
        System.out.println("请输入你要签收的序号");
        num = input.nextInt();
        for (int i = 0; i < dingDan.names.length; i++) {
            if (dingDan.names[i] != null && dingDan.zhuangTai[i
                    ] == false && i == num - 1) {

                System.out.println("订单签收成功");
                q = true;
                dingDan.zhuangTai[i] = true;
            } else if (dingDan.names != null && dingDan.zhuangTai[i] == true && i == num - 1) {
                System.out.println("您选择的订单已经被签收，不能再次签收");
                q = true;
            }
        }
        if (!q) {
            System.out.println("您选择的订单不在");
        }

    }

    public void delete() {
        boolean q = false;
        System.out.println("请选择要删除的订单序号");
        int num = input.nextInt();
        for (int i = 0; i < dingDan.names.length; i++) {
            if (dingDan.names[i] != null && dingDan.zhuangTai[i] == true && num == i + 1) {
                q = true;
                for (int j = num - 1; j < dingDan.names.length - 1; j++) {
                    dingDan.names[j] = dingDan.names[j + 1];
                    dingDan.caiMings[j] = dingDan.caiMings[j + 1];
                    dingDan.fenShu[j] = dingDan.fenShu[j + 1];
                    dingDan.shiJIan[j] = dingDan.shiJIan[j + 1];
                    dingDan.diZhi[i] = dingDan.diZhi[j + 1];
                    dingDan.sums[j] = dingDan.sums[j + 1];
                }

                int num1 = dingDan.names.length - 1;
                dingDan.names[num1] = null;
                dingDan.caiMings[num1] = null;
                dingDan.fenShu[num1] = 0;
                dingDan.shiJIan[num1] = null;
                dingDan.diZhi[num1] = null;
                dingDan.sums[num1] = 0;
                System.out.println("删除订单成功");
                break;
            } else if (dingDan.names != null && dingDan.zhuangTai[i] == false && num == i + 1) {
                System.out.println("您选择的订单未签收，不能删除！");
                q = true;
            }
        }
        if (!q) {
            System.out.println("你要删除的订单不存在");
        }
    }

    public void praise() {
        String priaiseNum = "";
        System.out.println("*****我要点赞*****");
        System.out.println();

        for (int i = 0; i < cai.names.length; i++) {
            String price = cai.danJia[i] + "元";
            priaiseNum =
                    (cai.dianZan[i] > 0 ? cai.dianZan[i] + "赞" : "");

            System.out.println((i + 1) + "\t" + cai.names[i] + "\t" + price + "\t" + priaiseNum);
        }
        System.out.println("请选择您要点赞的序号");
        int num = input.nextInt();
        cai.dianZan[num - 1]++;
        System.out.println();
//        for (int i = 0; i < cai.dianZan.length; i++) {
//            if(  i==num-1){
//                System.out.println("点赞成功");
//                cai.dianZan[i]++;
//            }
//        }
//        cai.dianZan[i]
    }

}
