package XuanZi.CH17项目案例.吃货联盟订餐系统.Zhao;

public class Test {
    public static void main(String[] args) {
        Util util = new Util();
        util.show();
    }
}
