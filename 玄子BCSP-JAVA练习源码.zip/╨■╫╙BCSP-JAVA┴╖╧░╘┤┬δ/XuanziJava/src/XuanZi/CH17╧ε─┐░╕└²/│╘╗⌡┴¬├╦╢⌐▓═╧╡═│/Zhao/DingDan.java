package XuanZi.CH17项目案例.吃货联盟订餐系统.Zhao;

public class DingDan {
    String[] names = new String[4];
    String[] caiMings = new String[4];
    int[] fenShu = new int[4];
    String[] shiJIan = new String[4];
    String[] diZhi = new String[4];
    boolean[] zhuangTai = new boolean[4];
    double[] sums = new double[4];
}
