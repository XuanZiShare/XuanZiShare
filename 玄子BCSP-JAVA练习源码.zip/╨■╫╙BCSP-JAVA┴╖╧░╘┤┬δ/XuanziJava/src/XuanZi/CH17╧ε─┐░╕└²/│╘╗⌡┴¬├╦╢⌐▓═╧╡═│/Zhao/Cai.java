package XuanZi.CH17项目案例.吃货联盟订餐系统.Zhao;

public class Cai {
    //    菜名，单价，点赞
    String[] names = new String[3];
    double[] danJia = new double[3];
    int[] dianZan = new int[3];
}
