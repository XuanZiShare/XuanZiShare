package XuanZi.CH17项目案例.吃货联盟订餐系统.YuYuZhao;

import java.util.Scanner;

public class Util {

    CaiDan[] caiDan = new CaiDan[4];
    DingDan[] dingDan = new DingDan[4];
    Scanner input = new Scanner(System.in);


    public void ChuShiHuaCaiDan() {
        caiDan[0] = new CaiDan("鱼香肉丝", 8, 90);
        caiDan[1] = new CaiDan("蒜薹炒肉", 9, 60);
        caiDan[2] = new CaiDan("麻婆豆腐", 10, 55);
        caiDan[3] = new CaiDan("胡辣汤", 5, 10000);
    }

    public void ChuShiHuaDingDan() {

        dingDan[0] = new DingDan("玄子", caiDan[0], 12, 0, "时代公寓", "已签收", "12:30");
        dingDan[1] = new DingDan("玉玉诏", caiDan[3], 12, 0, "时代公寓", "已签收", "12:30");
        dingDan[2] = new DingDan();
        dingDan[3] = new DingDan();

        dingDan[0].zongJinErs = caiDan[0].prices * dingDan[0].fenShus;
        dingDan[1].zongJinErs = caiDan[3].prices * dingDan[1].fenShus;
    }

    public void ZhuCaiDan() {
        ChuShiHuaCaiDan();
        ChuShiHuaDingDan();
        int jie1;
        //初始化主菜单
        do {
            System.out.println("欢迎使用吃货联盟订餐系统");
            System.out.println("***********************");
            System.out.println("1.我要订餐");
            System.out.println("2.查看餐袋");
            System.out.println("3.签收订单");
            System.out.println("4.删除订单");
            System.out.println("5.我要点赞");
            System.out.println("6.退出系统");
            System.out.println("************************");
            System.out.print("请选择：");
            int jie = input.nextInt();
            switch (jie) {
                case 1:
                    ZhuCaiDan1();
                    break;
                case 2:
                    ZhuCaiDan2();
                    break;
                case 3:
//                    ZhuCaiDan3();
                    break;
                case 4:
//                    ZhuCaiDan4();
                    break;
                case 5:
//                    ZhuCaiDan5();
                    break;
                case 6:
                default:
                    System.out.print("输入2退出，");
                    break;
            }
            System.out.println("输入0返回");
            jie1 = input.nextInt();
        } while (jie1 == 0);
        System.out.println("已退出订餐系统");

    }

    public void ZhuCaiDan1() {
        int canFei = 0;
        System.out.println("***我要订餐***");
        System.out.println("请输入订餐人姓名：");
        dingDan[2].names = input.next();

        System.out.println("序号\t" + "菜名\t" + "单价\t" + "点赞数\t");
        for (int i = 0; i < caiDan.length; i++) {
            System.out.println((i + 1) + "\t" + caiDan[i].names + "\t" + caiDan[i].prices + "\t" + caiDan[i].dainZans);
        }
        //展示菜单
        System.out.println("请选择您要点的菜品编号：");
        int jie1 = input.nextInt();
        System.out.println("请选择您要的份数：");
        int jie2 = input.nextInt();
        dingDan[2].fenShus = jie2;
        switch (jie1) {
            case 1:
                dingDan[2].caiDan = caiDan[0].names;
                canFei = dingDan[2].fenShus * caiDan[0].prices;
                break;
            case 3:
                dingDan[2].caiDan = caiDan[1].names;
                canFei = dingDan[2].fenShus * caiDan[1].prices;
                break;
            case 2:
                dingDan[2].caiDan = caiDan[2].names;
                canFei = dingDan[2].fenShus * caiDan[2].prices;
                break;
            case 4:
                dingDan[2].caiDan = caiDan[3].names;
                canFei = dingDan[2].fenShus * caiDan[3].prices;
                break;
        }
        //判断价格
        System.out.println("请选择您的送餐时间：(整点)");
        dingDan[2].songDa = input.next();

        System.out.println("请选择您的送餐地址：");
        dingDan[2].diZhis = input.next();

        System.out.println("送餐成功！");
        System.out.println("您定的是：" + dingDan[2].caiDan + dingDan[2].fenShus + "份");
        System.out.println("送餐时间：" + dingDan[2].songDa);
        int peiSongFei = jie2 >= 5 ? 0 : 5;
        //超过五份免配送费
        System.out.println("餐费：" + canFei + ",配送费" + peiSongFei + ",总计" + (canFei + peiSongFei) + "元。");
        dingDan[2].zongJinErs = canFei + peiSongFei;
        dingDan[2].zhuangTais = "未签收";
    }

    public void ZhuCaiDan2() {
        System.out.println("查看餐袋");
        System.out.println("序号" + "\t订餐人" + "\t餐品信息" + "\t送餐时间" + "\t送餐地址" + "\t总金额" + "\t订餐状态");
        for (int i = 0; i < dingDan.length; i++) {
            if (dingDan[i].names != null) {
                System.out.println((i + 1) + "\t" + dingDan[i].names + "\t" + caiDan[i].names + caiDan[i].prices + "\t" + dingDan[i].zhuangTais + "\t" + dingDan[i].diZhis + "\t" + dingDan[i].songDa + "\t" + dingDan[i].zhuangTais);
            }
        }
//        展示餐袋

    }

}
