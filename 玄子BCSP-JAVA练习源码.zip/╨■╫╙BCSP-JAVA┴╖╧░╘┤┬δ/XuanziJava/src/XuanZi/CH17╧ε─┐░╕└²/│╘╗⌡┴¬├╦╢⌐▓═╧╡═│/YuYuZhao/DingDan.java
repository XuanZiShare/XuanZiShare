package XuanZi.CH17项目案例.吃货联盟订餐系统.YuYuZhao;

public class DingDan {

    String names;
    //订单人姓名
    String caiDan;

    int fenShus;
    double zongJinErs;
    //    总金额
    //菜品份数
    String diZhis;

    //地址
    String songDa;
    String zhuangTais;
    //状态


    public DingDan() {

    }


    public DingDan(String names, CaiDan caiDan, int fenShus, double zongJinErs, String diZhis, String songDa, String zhuangTais) {
        this.names = names;
        this.caiDan = caiDan.toString();
        this.fenShus = fenShus;
        this.zongJinErs = zongJinErs;
        this.diZhis = diZhis;
        this.songDa = songDa;
        this.zhuangTais = zhuangTais;
    }
}
