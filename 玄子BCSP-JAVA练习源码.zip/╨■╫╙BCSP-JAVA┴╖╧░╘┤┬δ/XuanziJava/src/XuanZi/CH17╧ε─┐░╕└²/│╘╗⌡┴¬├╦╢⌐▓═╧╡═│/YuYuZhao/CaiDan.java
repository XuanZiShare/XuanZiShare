package XuanZi.CH17项目案例.吃货联盟订餐系统.YuYuZhao;

public class CaiDan {
    String names;
    //菜品的名字
    int prices;
    //菜品的单价
    int dainZans;
    //菜品的点赞数

    public CaiDan() {

    }

    public CaiDan(String names, int prices, int dainZans) {
        this.names = names;
        this.prices = prices;
        this.dainZans = dainZans;
    }


}
