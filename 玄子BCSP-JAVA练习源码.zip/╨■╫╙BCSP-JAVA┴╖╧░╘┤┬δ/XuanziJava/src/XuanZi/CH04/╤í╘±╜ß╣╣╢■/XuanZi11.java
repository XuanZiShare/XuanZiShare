package XuanZi.CH04.选择结构二;
//hasNextInt的使用

import java.util.Scanner;

public class XuanZi11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("欢迎来到商城请问你想要买什么？\n1.电脑\n2.手机\n3.耳机");
        if (input.hasNextInt()) {
            int num = input.nextInt();
            switch (num) {
                case 1:
                    System.out.println("购买了电脑");
                    break;
                case 2:
                    System.out.println("购买了手机");
                    break;
                case 3:
                    System.out.println("购买了耳机");
                    break;
                default:
                    System.out.println("输入错误。");
                    break;
            }
        } else {
            System.out.println("请输入正确的数字！");
        }

    }

}
