package XuanZi.CH04.选择结构二;
//Switch的基础使用

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("华硕客服电话：");
        System.out.println("商品咨询请按1");
        System.out.println("售后服务请按2");
        System.out.println("问题反馈请按3");
        System.out.println("其他问题请按4");
        System.out.print("请输入选择：");
        int i = input.nextInt();
        switch (i) {
            case 1:
                System.out.println("商品咨询");
                break;
            case 2:
                System.out.println("售后");
                break;
            case 3:
                System.out.println("反馈");
                break;
            case 4:
                System.out.println("转接人工");
                break;
            default:
                System.out.println("不问滚蛋");
                break;
        }
    }
}
