package XuanZi.CH04.选择结构二;
//商品换购
import java.util.Scanner;

public class XuanZi05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String sp01Name = "一瓶可口可乐";
        String sp02Name = "5斤面粉";
        String sp03Name = "一瓶爽肤水";
        String sp04Name = "一个炒菜锅";

        int sp01Jg = 2;
        int sp02Jg = 4;
        int sp03Jg = 6;
        int sp04Jg = 8;

        String tiShi = "请输入正确选择";
        String jiaGeBuGo = "您的金额不足换购条件";
        String huanGo = "您已退出换购活动";

        System.out.println("是否要参加购物换购活动（y/n）：");
        String canJIa = input.next();
        switch (canJIa) {
            case "y":
                System.out.println("请输入您的消费金额：");
                int jie1 = input.nextInt();

                if (jie1 <= 50 && jie1 > 0) {
                    System.out.println("您可以加" + sp01Jg + "元换购" + sp01Name);
                    System.out.println("是否换购？（y/n）");
                    String jie2 = input.next();
//                    switch (jie2) {
//                        case "y":
//                            System.out.println("换购成功消费" + (jie1 + sp01Jg) + "元");
//                            break;
//                        case "n":
//                            System.out.println(huanGo);
//                            break;
//                        default:
//                            System.out.println(tiShi);
//                            break;
//
//                    }
                    if (jie2 .equals("y"))  {
                        System.out.println("换购成功消费" + (jie1 + sp01Jg) + "元");
                    } else if (jie2 .equals("n")) {
                        System.out.println(huanGo);
                    } else {
                        System.out.println(tiShi);
                    }
                    break;
                } else if (jie1 <= 100 && jie1 > 50) {
                    System.out.println("您可以加" + sp02Jg + "元换购" + sp02Name);
                    System.out.println("是否换购？（y/n）");
                    String jie22 = input.next();
                    switch (jie22) {
                        case "y":
                            System.out.println("换购成功消费" + (jie1 + sp02Jg) + "元");
                            break;
                        case "n":
                            System.out.println(huanGo);
                            break;
                        default:
                            System.out.println(tiShi);
                            break;
                    }
                    break;
                } else if (jie1 <= 200 && jie1 > 100) {
                    System.out.println("您可以加" + sp03Jg + "元换购" + sp03Name);
                    System.out.println("是否换购？（y/n）");
                    String jie23 = input.next();
                    switch (jie23) {
                        case "y":
                            System.out.println("换购成功消费" + (jie1 + sp03Jg) + "元");
                            break;
                        case "n":
                            System.out.println(huanGo);
                            break;
                        default:
                            System.out.println(tiShi);
                            break;
                    }
                    break;
                } else if (jie1 >= 300) {
                    System.out.println("您可以加" + sp04Jg + "元换购" + sp04Name);
                    System.out.println("是否换购？（y/n）");
                    String jie24 = input.next();
                    switch (jie24) {
                        case "y":
                            System.out.println("换购成功消费" + (jie1 + sp04Jg) + "元");
                            break;
                        case "n":
                            System.out.println(huanGo);
                            break;
                        default:
                            System.out.println(tiShi);
                            break;
                    }
                    break;
                } else {
                    System.out.println("没买东西你换什么？");
                }
            case "n":
                System.out.println(huanGo);
                break;
            default:
                System.out.println(tiShi);
                break;


        }
    }
}