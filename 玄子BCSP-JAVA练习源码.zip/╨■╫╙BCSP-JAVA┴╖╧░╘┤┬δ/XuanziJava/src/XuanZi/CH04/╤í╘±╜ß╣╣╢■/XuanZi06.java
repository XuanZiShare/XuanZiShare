package XuanZi.CH04.选择结构二;
//case中break的使用
import java.util.Scanner;

public class XuanZi06 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        System.out.println("请输入您的月份：");
        int i = inout.nextInt();
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 12:
                System.out.println("淡季");
                System.out.println("头等舱1");
                System.out.println("经济舱2");
                int j = inout.nextInt();
                switch (j) {
                    case 1:
                        System.out.println("票价2500元");
                        break;
                    case 2:
                        System.out.println("票价2000元");
                        break;
                }
                break;
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
                System.out.println("旺季");
                System.out.println("头等舱1");
                System.out.println("经济舱2");
                int j1 = inout.nextInt();
                switch (j1) {
                    case 1:
                        System.out.println("票价4500元");
                        break;
                    case 2:
                        System.out.println("票价4000元");
                        break;

                }
            default:
                System.out.println("请输入正确选择");
                break;
        }

    }
}
