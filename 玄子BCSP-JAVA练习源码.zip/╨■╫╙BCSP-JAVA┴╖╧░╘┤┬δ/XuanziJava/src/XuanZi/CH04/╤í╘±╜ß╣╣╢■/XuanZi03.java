package XuanZi.CH04.选择结构二;
//嵌套判断
import java.util.Scanner;

public class XuanZi03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("商城购物：");
        System.out.println("登录请按1");
        System.out.println("退出请按2");
        int jie1 = scanner.nextInt();
        switch (jie1) {
            case 1:
                System.out.println("1.客户1管理");
                System.out.println("2.客户2管理");
                System.out.println("3.客户3管理");
                System.out.println("4.客户4管理");
                int jie2 = scanner.nextInt();
                switch (jie2) {
                    case 1:
                        System.out.println("1.客户11管理");
                        System.out.println("1.客户111管理");
                        System.out.println("1.客户1111管理");
                        System.out.println("1.客户11111管理");
                        int jie3 = scanner.nextInt();
                        switch (jie3) {
                            case 1:
                                System.out.println("1.客户111111管理");
                                break;
                            case 2:
                                System.out.println("1.客户11111111管理");
                                break;
                            case 3:
                                System.out.println("1.客户1111111111管理");
                                break;
                            case 4:
                                System.out.println("1.客户111111111111管理");
                                break;
                            default:
                                System.out.println("输入正确数字");
                                break;

                        }
                        break;
                    case 2:
                        System.out.println("2.客户2管理");
                        break;
                    case 3:
                        System.out.println("3.客户3管理");
                        break;
                    case 4:
                        System.out.println("4.客户4管理");
                        break;
                    default:
                        System.out.println("输入正确选择");
                        break;
                }
            case 2:
                System.out.println("退出");
                break;
            default:
                System.out.println("输入正确答案");
                break;

        }
    }
}