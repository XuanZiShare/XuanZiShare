package XuanZi.CH04.选择结构二;
//商城项目
import java.util.Scanner;

public class XuanZi04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("欢迎使用玄子商城1.0");
        System.out.println("\t\t\t1.登录");
        System.out.println("\t\t\t2.退出");
        System.out.println("**********************************************");
        System.out.print("请选择:");
        if (input.hasNextInt() == true) {
            int jie1 = input.nextInt();
            switch (jie1) {
                case 1:
                    System.out.println("欢迎使用玄子商场");
                    System.out.println("**********************************************");
                    System.out.println("\t\t\t1.客户信息管理");
                    System.out.println("\t\t\t2.购物结算");
                    System.out.println("\t\t\t3.真情回馈");
                    System.out.println("\t\t\t4.注销");
                    System.out.println("**********************************************");
                    System.out.print("请选择:");
                    if (input.hasNextInt() == true) {
                        int jie11 = input.nextInt();
                        switch (jie11) {
                            case 1:
                                System.out.println("\t\t\t1.客户信息管理");
                                break;
                            case 2:
                                System.out.println("\t\t\t2.购物结算");
                                break;
                            case 3:
                                System.out.println("\t\t\t3.真情回馈");
                                break;
                            case 4:
                                System.out.println("1");
                                break;
                            default:
                                System.out.println("请输入正确选择");
                                break;
                        }
                    } else {

                    }
                    System.out.println("请输入正确选择");

                    break;
                case 2:
                    System.out.println("\t");
                    break;
                default:
                    System.out.println("请输入正确选择");
                    break;
            }

        } else {
            System.out.println("请输入正确选择");
        }
    }
}
