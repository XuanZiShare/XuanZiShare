package XuanZi.CH04.选择结构二;
//年份相差计算器

import java.util.Scanner;

public class XuanZi07 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("欢迎使用年份相差计算器");
        System.out.print("请输入年份：");
        int year = input.nextInt();
        System.out.println("请输入月份");
        int month = input.nextInt();
        System.out.println("请输入日份");
        int date = input.nextInt();

        switch (month - 1) {
            case 11:
                date += 30;
            case 10:
                date += 31;
            case 9:
                date += 30;
            case 8:
                date += 31;
            case 7:
                date += 31;
            case 6:
                date += 30;
            case 5:
                date += 31;
            case 4:
                date += 30;
            case 3:
                date += 31;
            case 2:
                if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0) && (year != 0)) {
                    date += 29;
                } else {
                    date += 28;
                }
            case 1:
                date += 31;
                break;
            default:
                System.out.println("请输入正确月份");
                break;
        }

        if (month >= 1 && month <= 12) {
            System.out.println("今天是" + year + "年的第" + date + "天");
        }
    }
}