package XuanZi.CH04.选择结构二;
//判断结构综合练习

import java.util.Scanner;

public class XuanZi09 {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
        System.out.println("欢迎来到玄子商场，请输入你想要去的区域");
        System.out.println("1.游戏区");
        System.out.println("2.餐饮区");
        System.out.println("3.服装区");
        System.out.println("4.影音区");
        System.out.println("5.休闲区");
        System.out.print("请输入你想要去的区域：");
        int jie1 = input.nextInt();
        switch (jie1) {
            case 1:
                System.out.println("欢迎来到游戏区,请输入你想玩啥");
                System.out.println("1.王者\n"+"2.吃鸡\n"+"3.永杰\n");
                int jie2 = input.nextInt();
                if (jie2 == 1) {
                    System.out.println("打王者");
                    System.out.println("欢迎来到王者,请输入你想玩啥");
                    System.out.println("1.匹配\n"+"2.排位\n"+"3.娱乐\n");
                    int cjie1 = input.nextInt();
                    if (cjie1 == 1) {
                        System.out.println("打匹配");

                    }else if(cjie1 == 2){
                        System.out.println("打排位");
                    }else if (cjie1 == 3) {
                        System.out.println("打娱乐");
                    }else {
                        System.out.println("不玩滚");
                    }
                }else if(jie2 == 2){
                    System.out.println("打吃鸡");
                    System.out.println("欢迎来到吃鸡,请输入你想玩啥");
                    System.out.println("1.匹配\n"+"2.排位\n"+"3.娱乐\n");
                    int cjie2 = input.nextInt();
                    if (cjie2 == 1) {
                        System.out.println("打匹配");

                    }else if(cjie2 == 2){
                        System.out.println("打排位");
                    }else if (cjie2 == 3) {
                        System.out.println("打娱乐");
                    }else {
                        System.out.println("不玩滚");
                    }
                }else if (jie2 == 3) {
                    System.out.println("打永杰");
                    System.out.println("欢迎来到永杰,请输入你想玩啥");
                    System.out.println("1.匹配\n"+"2.排位\n"+"3.娱乐\n");
                    int cjie3 = input.nextInt();
                    if (cjie3 == 1) {
                        System.out.println("打匹配");

                    }else if(cjie3 == 2){
                        System.out.println("打排位");
                    }else if (cjie3 == 3) {
                        System.out.println("打娱乐");
                    }else {
                        System.out.println("不玩滚");
                    }
                }else {
                    System.out.println("不玩滚");
                }
                break;
            case 2:
                System.out.println("欢迎来到餐饮区,请输入你想吃啥");
                System.out.println("""
                        1.炸鸡
                        2.面条
                        3.米饭
                        """);
                int jie3 = input.nextInt();
                if (jie3 == 1) {
                    System.out.println("吃炸鸡");
                    System.out.println("欢迎来到炸鸡,请输入你想吃啥");
                    System.out.println("1.凉的\n"+"2.热的\n"+"3.温的\n");
                    int cjie11 = input.nextInt();
                    if (cjie11 == 1) {
                        System.out.println("吃凉的");

                    }else if(cjie11 == 2){
                        System.out.println("吃热的");
                    }else if (cjie11 == 3) {
                        System.out.println("吃温的");
                    }else {
                        System.out.println("不吃滚");
                    }
                }else if(jie3 == 2){
                    System.out.println("吃面条");
                    System.out.println("欢迎来到面条,请输入你想吃啥");
                    System.out.println("1.凉的\n"+"2.热的\n"+"3.温的\n");
                    int cjie22 = input.nextInt();
                    if (cjie22 == 1) {
                        System.out.println("吃凉的");

                    }else if(cjie22 == 2){
                        System.out.println("吃热的");
                    }else if (cjie22 == 3) {
                        System.out.println("吃温的");
                    }else {
                        System.out.println("不吃滚");
                    }
                }else if (jie3 == 3) {
                    System.out.println("吃米饭");
                    System.out.println("欢迎来到米饭,请输入你想吃啥");
                    System.out.println("1.凉的\n"+"2.热的\n"+"3.温的\n");
                    int cjie33 = input.nextInt();
                    if (cjie33 == 1) {
                        System.out.println("吃凉的");

                    }else if(cjie33 == 2){
                        System.out.println("吃热的");
                    }else if (cjie33 == 3) {
                        System.out.println("吃温的");
                    }else {
                        System.out.println("不吃滚");
                    }
                }else {
                    System.out.println("不吃滚");
                }
                break;
            case 3:
                System.out.println("欢迎来到服装区,请输入你想穿啥");
                System.out.println("""
                        1.短袖
                        2.短裤
                        3.凉鞋
                        """);
                int jie4 = input.nextInt();
                switch (jie4) {
                    case 1:
                        System.out.println("穿短袖");
                        System.out.println("欢迎来到穿短袖,请输入你想穿多大");
                        System.out.println("""
                        1.m
                        2.mm
                        3.mmm
                        """);
                        int jie41 = input.nextInt();
                        switch (jie41) {
                            case 1:
                                System.out.println("穿m");
                                break;
                            case 2:
                                System.out.println("穿mm");
                                break;
                            case 3:
                                System.out.println("穿mmm");
                                break;
                            default:
                                System.out.println("不穿滚蛋");
                                break;
                        }
                    break;
                    case 2:
                        System.out.println("穿短裤");
                        System.out.println("欢迎来到穿短裤,请输入你想穿多大");
                        System.out.println("""
                        1.m
                        2.mm
                        3.mmm
                        """);
                        int jie42 = input.nextInt();
                        switch (jie42) {
                            case 1:
                                System.out.println("穿m");
                                break;
                            case 2:
                                System.out.println("穿mm");
                                break;
                            case 3:
                                System.out.println("穿mmm");
                                break;
                            default:
                                System.out.println("不穿滚蛋");
                                break;
                        }
                    break;
                    case 3:
                        System.out.println("穿凉鞋");
                        System.out.println("欢迎来到穿短裤,请输入你想穿多大");
                        System.out.println("""
                        1.m
                        2.mm
                        3.mmm
                        """);
                        int jie43 = input.nextInt();
                        switch (jie43) {
                            case 1:
                                System.out.println("穿m");
                                break;
                            case 2:
                                System.out.println("穿mm");
                                break;
                            case 3:
                                System.out.println("穿mmm");
                                break;
                            default:
                                System.out.println("不穿滚蛋");
                                break;
                        }
                    break;
                    default:
                        System.out.println("不穿滚蛋");
                    break;
                }
                break;
            case 4:
                System.out.println("欢迎来到影音区,请输入你想看啥");
                System.out.println("""
                        1.电影
                        2.听歌
                        3.蹦迪
                        """);
                int jie5 = input.nextInt();
                switch (jie5) {
                    case 1:
                        System.out.println("看电影");
                        System.out.println("欢迎来到看电影,请输入你想看多久");
                        System.out.println("""
                        1.1分钟
                        2.10分钟
                        3.100分钟
                        """);
                        int jie51 = input.nextInt();
                        switch (jie51) {
                            case 1:
                                System.out.println("搞1分钟");
                                break;
                            case 2:
                                System.out.println("搞10分钟");
                                break;
                            case 3:
                                System.out.println("搞100分钟");
                                break;
                            default:
                                System.out.println("不搞滚蛋");
                                break;
                        }
                        break;
                    case 2:
                        System.out.println("想听歌");
                        System.out.println("欢迎来到想听歌,请输入你想看多久");
                        System.out.println("""
                        1.1分钟
                        2.10分钟
                        3.100分钟
                        """);
                        int jie52 = input.nextInt();
                        switch (jie52) {
                            case 1:
                                System.out.println("搞1分钟");
                                break;
                            case 2:
                                System.out.println("搞10分钟");
                                break;
                            case 3:
                                System.out.println("搞100分钟");
                                break;
                            default:
                                System.out.println("不搞滚蛋");
                                break;
                        }
                        break;
                    case 3:
                        System.out.println("要蹦迪");
                        System.out.println("欢迎来到要蹦迪,请输入你想看多久");
                        System.out.println("""
                        1.1分钟
                        2.10分钟
                        3.100分钟
                        """);
                        int jie53 = input.nextInt();
                        switch (jie53) {
                            case 1:
                                System.out.println("搞1分钟");
                                break;
                            case 2:
                                System.out.println("搞10分钟");
                                break;
                            case 3:
                                System.out.println("搞100分钟");
                                break;
                            default:
                                System.out.println("不搞滚蛋");
                                break;
                        }
                        break;
                    default:
                        System.out.println("不看滚蛋");
                        break;
                }
                break;
            case 5:
                System.out.println("欢迎来到休闲区,请输入你想干啥");
                System.out.println("""
                        1.睡觉
                        2.唠嗑
                        3.阿巴巴巴
                        """);
                int jie6 = input.nextInt();
                switch (jie6) {
                    case 1 -> System.out.println("想睡觉");
                    case 2 -> System.out.println("要唠嗑");
                    case 3 -> System.out.println("阿巴巴巴");
                    default -> System.out.println("不干滚蛋");
                }
                break;
            default:
                System.out.println("不玩滚蛋");
                break;
        }
    }
}
