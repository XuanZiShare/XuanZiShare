package XuanZi.CH04.选择结构二;
//逻辑运算符与断路运算符的区别

public class XuanZi10 {
    public static void main(String[] args) {

        int i = 5;
        int j = 10;
        if (i++ > 5 && ++j > 10) {
            System.out.println("A!");
        } else {
            System.out.println("B!");
        }
        System.out.println(i);
        //第一个i的条件不满足立即停止
        System.out.println(j);
        System.out.println("--------------------------------");
        int q = 5;
        int p = 10;
        if (q++ > 5 & ++p > 10) {
            System.out.println("A!");
        } else {
            System.out.println("B!");
        }
        System.out.println(q);
        //即使第一个q的条件不满足，也会把第二个p的条件比较完，再进行判断
        System.out.println(p);

        /*
        “&&”是按顺序一个一个地比较，当比较对象出现false时就停止比较，
        而“&”是将所有对象全部比较之后（出现false时不会立即停止），最后再比较。
        */
    }
}
