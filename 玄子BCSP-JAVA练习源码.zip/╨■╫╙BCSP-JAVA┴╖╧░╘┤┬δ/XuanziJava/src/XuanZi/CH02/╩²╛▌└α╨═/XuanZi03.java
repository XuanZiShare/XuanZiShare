package XuanZi.CH02.数据类型;
//变量数据类型

public class XuanZi03 {
    public static void main(String[] args) {


        String brand = "爱国者";
        double weight = 12.4;
        String type = "内置锂电池";
        int price = 499;

        System.out.println(brand + weight + type + price);
        //定以后输出

    }
}
