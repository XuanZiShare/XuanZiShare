package XuanZi.CH02.数据类型;
//类型转换

public class XuanZi08 {
    public static void main(String[] args) {

        int a = 1;
        double c = a;
        double b = 1.5;
        int e = (int) b;


    }
}
