package XuanZi.CH02.数据类型;
//算数运算

public class XuanZi12 {

    public static void main(String[] args) {
        int a =1;
        //整形
        double b =3.14;
        //浮点型
        String c = "字符串";
        //字符串
        char d = '男';
        //单字符
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        //打印数据类型值
        boolean xz1=a<b;
        boolean xz2=a>b;
        boolean xz3=a==b;
        boolean xz4=a!=b;
        boolean xz5=a>=b;
        boolean xz6=a<=b;
        //布尔型判断
        System.out.println(xz1);
        System.out.println(xz2);
        System.out.println(xz3);
        System.out.println(xz4);
        System.out.println(xz5);
        System.out.println(xz6);
        //打印布尔判断
        System.out.println(a-b);
        System.out.println(a+b);
        System.out.println(((a*b)*b)>=100);
        System.out.println(a/b);
        System.out.println(a%b);
        System.out.println(125/10%10);
        System.out.println(10/5.0);
        System.out.println(a++);
        System.out.println(a--);
        System.out.println(a+=3);
        System.out.println(a-=3);
        System.out.println(a*=3);
        System.out.println(a/=3);
        //算数运算符计算


    }
}