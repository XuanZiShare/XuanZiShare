package XuanZi.CH02.数据类型;
//三目运算

public class XuanZi09 {
    public static void main(String[] args) {
        int score = 90;
        String judge = score >= 60 ? "合格" : "不合格";
//                       布尔表达式       表达式1    表达式2
        System.out.println(judge);
    }
}
