package XuanZi.CH02.数据类型;
//计算

public class XuanZi05 {
    public static void main(String[] args) {


        int day = 46;
        System.out.println(day / 7);
        System.out.println(day % 7);
//算术运算

    }
}
