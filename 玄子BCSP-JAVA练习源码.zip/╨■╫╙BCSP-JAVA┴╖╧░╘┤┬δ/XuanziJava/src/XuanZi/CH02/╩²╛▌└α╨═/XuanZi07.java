package XuanZi.CH02.数据类型;
//计算圆面积

public class XuanZi07 {
    public static void main(String[] args) {

        double radius = 1.5;
        double π = 3.141592653;
        System.out.println(π * radius * radius);

    }
}
