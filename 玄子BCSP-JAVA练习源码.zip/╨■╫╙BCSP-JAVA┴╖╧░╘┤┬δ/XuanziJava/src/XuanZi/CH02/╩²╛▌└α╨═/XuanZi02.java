package XuanZi.CH02.数据类型;
//变量数据类型

public class XuanZi02 {
    public static void main(String[] args) {

        int a = 1;
        double b = 3.1415;
        String c = "字符串";

        System.out.println("""
                1.3131
                2.1415
                3.1415""");
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println("a+b等于:" + (a + b));


    }
}
