package XuanZi.CH02.数据类型;
//变量数据类型

public class XuanZi04 {
    public static void main(String[] args) {

        int math = 89;
        int chinese = 99;
        int english = 120;
        System.out.println((math + chinese + english) / 3);
        //平均分的计算


    }
}
