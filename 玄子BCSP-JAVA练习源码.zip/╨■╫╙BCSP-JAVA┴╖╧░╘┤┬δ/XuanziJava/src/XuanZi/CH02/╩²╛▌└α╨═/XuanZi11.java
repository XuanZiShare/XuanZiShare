package XuanZi.CH02.数据类型;
//商城购物

import java.util.Scanner;

public class XuanZi11 {
    public static void main(String[] args) {
        Scanner inout = new Scanner(System.in);
        System.out.println("*******消费单********");
        System.out.println("物品\t  单价  数量\t 合计");

        String sp1 = "电脑";
        String sp2 = "鼠标";
        String sp3 = "键盘";

        int sp1Price = 70000;
        int sp2Price = 120;
        int sp3Price = 150;

        int sp1Mum = 1;
        int sp2Mum = 2;
        int sp3Mum = 3;

        System.out.println(sp1 + "\t " + sp1Price + " \t" + sp1Mum + "\t" + sp1Price * sp1Mum);
        System.out.println(sp2 + "\t " + sp2Price + " \t" + sp2Mum + "\t" + sp2Price * sp2Mum);
        System.out.println(sp3 + "\t " + sp2Price + " \t" + sp3Mum + "\t" + sp3Price * sp3Mum);
        System.out.println("折扣：8折");
        double price = (sp1Price * sp1Mum + sp2Price * sp2Mum + sp3Price * sp3Mum);
        System.out.println("共计花费：" + price);
        System.out.print("实际缴费：");
        int len = inout.nextInt();
        System.out.println("找钱：" + (len - price));
        System.out.println("所获积分：" + price * 0.0005);

    }
}
