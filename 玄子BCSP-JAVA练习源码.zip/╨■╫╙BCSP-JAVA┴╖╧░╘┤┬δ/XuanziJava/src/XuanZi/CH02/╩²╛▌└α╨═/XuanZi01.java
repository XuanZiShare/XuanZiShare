package XuanZi.CH02.数据类型;
//变量数据类型

public class XuanZi01 {
    public static void main(String[] args) {

        int age = 18;
        //声明整数18
        String name = "John Doe";
//        声明字符串  John Doe
        System.out.println(name + age);
        //拼合输出


    }
}
