package XuanZi.CH02.数据类型;
//扫描器

import java.util.Scanner;

public class XuanZi10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //Scanner 扫描器
        System.out.println("请输入花费金额：");
        int Len = input.nextInt();
        //接收整形
        double i = Len * 0.8;
        System.out.println(i);
        //输出
    }
}
