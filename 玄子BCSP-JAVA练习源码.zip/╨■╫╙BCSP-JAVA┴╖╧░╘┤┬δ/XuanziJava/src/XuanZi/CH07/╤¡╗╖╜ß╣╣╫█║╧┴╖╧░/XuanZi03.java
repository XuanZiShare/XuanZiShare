package XuanZi.CH07.循环结构综合练习;

import java.util.Scanner;

public class XuanZi03 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int bi = 0;
        int zhe = 0;
        String jie3 = null;
        System.out.println("青鸟游戏平台 > 游戏币支付");
        System.out.println("请选择你的游戏类型：");
        System.out.println("1.牌类");
        System.out.println("2.休闲类");
        int jie1 = input.nextInt();
        System.out.println("请输入游戏时长：");
        int jie2 = input.nextInt();
        switch (jie1) {

            case 1:
                jie3 = "牌类";
                if (jie2 <= 10) {
                    bi = jie2 * 8 * 10;
                    zhe = 8;
                } else {
                    bi = jie2 * 5 * 10;
                    zhe = 5;
                }
                break;
            case 2:
                jie3 = "休闲类";

                if (jie2 <= 10) {

                    bi = jie2 * 8 * 20;
                    zhe = 8;
                } else {
                    bi = jie2 * 5 * 20;
                    zhe = 5;
                }
                break;
            default:
                System.out.println("请输入1-2");
                break;
        }
        System.out.println("您正在玩的是" + jie3 + "游戏，时长是：" + jie2 + "小时" + "可以享受" + zhe + "折优惠您需要支付" + bi + "个游戏币");
    }
}
