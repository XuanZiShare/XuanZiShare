package XuanZi.CH07.循环结构综合练习;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        System.out.println("青鸟游戏平台> 游戏晋级");
        int i = 1;
        int j1;
        boolean moren = true;
        String que = "";
        int ju1 = 0;
        int ju2 = 0;
        do {
            Scanner input = new Scanner(System.in);
            System.out.println("您正在玩第" + (i++) + "局" + "成绩为：");
            j1 = input.nextInt();
            if (j1 >= 80) {
                ju2 += 1;
                ju1 += 1;
            } else if (j1 >= 60) {
                ju1 += 1;
            }
            System.out.println("继续玩下一局吗？（yes/no）");
            que = input.next();
            if (que.equals("no")) {
                System.out.println("您已中途退出游戏");
                moren = false;
                break;
            } else if (que.equals("yes") && i <= 5) {
                System.out.println("进入下一局");
            }
        } while (i <= 5);
        if (ju1 >= 4 && moren != false) {
            System.out.println("一级");
            System.out.println("晋级");
        } else if (ju2 >= 3 && moren != false) {
            System.out.println("二级");
            System.out.println("晋级");
        } else {
            System.out.println("失败");
        }

    }
}
