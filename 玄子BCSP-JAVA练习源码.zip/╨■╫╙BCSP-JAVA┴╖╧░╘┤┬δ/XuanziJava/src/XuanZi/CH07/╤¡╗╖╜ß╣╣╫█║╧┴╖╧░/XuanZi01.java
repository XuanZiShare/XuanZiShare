package XuanZi.CH07.循环结构综合练习;

import java.util.Scanner;

public class XuanZi01 {
    public static void main(String[] args) {
        boolean moren = true;
        do {
            Scanner inout = new Scanner(System.in);


            System.out.println("欢迎进入青鸟游戏迷你平台：");
            System.out.println();
            System.out.println("请选择你喜爱的游戏");
            System.out.println("************************");
            System.out.println("1.斗地主");
            System.out.println("2.斗牛");
            System.out.println("3.炸金花");
            System.out.println("4.连连看");
            System.out.println("请选择，输入数字：");
            if (inout.hasNextInt()) {
                moren = true;
                int wadaddaw = inout.nextInt();
                switch (wadaddaw) {
                    case 1:
                        System.out.println("斗地主");
                        break;
                    case 2:
                        System.out.println("斗牛");
                        break;
                    case 3:
                        System.out.println("炸金花");
                        break;
                    case 4:
                        System.out.println("连连看");
                        break;
                    default:
                        System.out.println("请输入0-4的数字");
                        moren = false;
                        break;
                }
            } else {
                System.out.println("请输入数字");
                moren = false;
            }
        } while (moren == false);
    }
}
