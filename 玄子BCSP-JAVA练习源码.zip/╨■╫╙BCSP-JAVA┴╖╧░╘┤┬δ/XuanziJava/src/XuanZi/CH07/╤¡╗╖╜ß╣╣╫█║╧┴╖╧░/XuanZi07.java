package XuanZi.CH07.循环结构综合练习;

import java.util.Scanner;

public class XuanZi07 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int bi = 0;

        int cjie1 = 0;
        int zheKou = 0;
        System.out.println("青鸟游戏平>游戏币");
        for (int i = 0; i <= 5; i++) {
            System.out.println("请输入想玩的游戏：\n1.棋牌类2.休闲类");
            int jie1 = input.nextInt();
            switch (jie1) {
                case 1:
                    System.out.println("1");
                    System.out.println("请输入游戏时长：");
                    cjie1 = input.nextInt();
                    if (cjie1 < 10) {
                        bi = cjie1 * 10 * 8;
                    } else {
                        bi = cjie1 * 10 * 5;
                    }
                    break;
                case 2:
                    System.out.println("2");
                    System.out.println("请输入游戏时长：");
                    cjie1 = input.nextInt();
                    if (cjie1 < 10) {
                        bi = cjie1 * 20 * 8;
                    } else {
                        bi = cjie1 * 20 * 5;
                    }
                    break;
                default:
                    System.out.println("unknown");
                    break;
            }
            System.out.println("您玩的是" + jie1 + "游戏时长" + cjie1 + "游戏币" + bi);
        }
    }
}
