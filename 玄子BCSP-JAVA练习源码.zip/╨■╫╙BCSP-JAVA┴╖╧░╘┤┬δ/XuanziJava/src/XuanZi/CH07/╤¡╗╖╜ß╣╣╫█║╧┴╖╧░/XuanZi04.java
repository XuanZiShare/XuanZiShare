package XuanZi.CH07.循环结构综合练习;

import java.util.Scanner;

public class XuanZi04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("玩什么？\n1.牌类\n2.休闲类");
        int num = input.nextInt();
        int price = num == 1 ? 10 : 20;
        String type = num == 1 ? "牌" : "休闲";
        System.out.println("游戏时长");
        int hours = input.nextInt();
        int zhekou = hours >= 10 ? 5 : 8;
        System.out.println("您玩的是" + type + "类型游戏，时长是" + hours + "小时，可以享受" + zhekou + "折优惠" + "您需要支付" + price + hours + zhekou / 100 + "个游戏币");
    }
}
