package XuanZi.CH07.循环结构综合练习;

import java.util.Scanner;

public class XuanZi05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int c = 0;
        int i = 0;
        System.out.println("青鸟游戏迷你平台 < 游戏点击率");
        for (i = 1; i <= 4; i++) {
            System.out.println("请输入第" + i + "个游戏的点击率：");
            int j = input.nextInt();
            if (j >= 100) {
                c++;
            }
        }
        double rate = (double) c / 4 * 100;
        System.out.println("点击率大于100的游戏数是：" + c + "比例是：" + rate + "%");

    }
}
