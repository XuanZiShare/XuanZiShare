package XuanZi.CH07.循环结构综合练习;

import java.util.Scanner;

public class XuanZi06 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int bianHao = 0;
        int age = 0;
        int jiFen = 0;
        System.out.println("青鸟游戏迷你平台 < 添加用户信息");
        System.out.println("请输入录入用户数量：");
        int i = input.nextInt();
        for (int q = 1; q <= i; q++) {
            System.out.println("请输入用户编号（<4位数>）");
            bianHao = input.nextInt();
            System.out.println("请输入用户年龄");
            age = input.nextInt();
            if (age < 18) {
                System.out.println("未成年不给玩");
                System.out.println("录入信息失败");
            } else {
                System.out.println("请输入用户积分");
                jiFen = input.nextInt();
                System.out.println("您录入的信息是：\n用户编号：" + bianHao + "年龄：" + age + "积分" + jiFen);

            }

        }
    }
}
