package LearnJava.天数相差计算器;
//天数相差计算器，思路2

import java.util.Scanner;

public class 天数相差计算器02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //扫描器
        System.out.println("欢迎使用年份相差计算器");
        System.out.println("请输入年份");
        int year = input.nextInt();
        System.out.println("请输入月份");
        int month = input.nextInt();
        System.out.println("请输入日份");
        int day = input.nextInt();
//        接收用户输入值
        boolean riQi = true;
//判断非法输入
        if (year <= 0 || month <= 0 || day <= 0 || month > 12 || day > 31) {
            System.out.println("请输入正确的时间");
            riQi = false;
        }
//        如果输入错误日期终止运行
//            System.exit(0);
        if (riQi) {
//            如果没有非法输入就正常运行

            switch (month - 1) {
                //月份减去1，因为会直接加上输入的日期
//                switch不写break就会一直运行直到程序结束或者遇见break
                case 11:
                    day += 30;
                case 10:
                    day += 31;
                case 9:
                    day += 30;
                case 8:
                    day += 31;
                case 7:
                    day += 31;
                case 6:
                    day += 30;
                case 5:
                    day += 31;
                case 4:
                    day += 30;
                case 3:
                    day += 31;
                case 2:
                    if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0) && (year != 0)) {
                        day += 29;
                    } else {
                        day += 28;
                    }
                case 1:
                    day += 31;
                    break;
                //最后的day就是用户输入的年份所过的日期
            }
            System.out.println("今天是" + year + "年的第" + day + "天");
//            输出出来 就可以了
        }

    }

}
