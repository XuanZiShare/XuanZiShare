package LearnJava.天数相差计算器;
//天数相差计算器，思路4
//前两个案例的总结，自行理解
//计算任意两个年份之间的天数差距

import java.util.Scanner;

public class 天数相差计算器04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("欢迎使用年份相差计算器(双向版)");
        System.out.print("请输入年份：");
        int year = input.nextInt();
        System.out.print("请输入月份：");
        int month = input.nextInt();
        System.out.print("请输入日份：");
        int date = input.nextInt();

        switch (month - 1) {
            case 11:
                date += 30;
            case 10:
                date += 31;
            case 9:
                date += 30;
            case 8:
                date += 31;
            case 7:
                date += 31;
            case 6:
                date += 30;
            case 5:
                date += 31;
            case 4:
                date += 30;
            case 3:
                date += 31;
            case 2:
                if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0) && (year != 0)) {
                    date += 29;
                } else {
                    date += 28;
                }
            case 1:
                date += 31;
                break;
            default:
                System.out.println("请输入正确月份");
                break;
        }

        if (month >= 1 && month <= 12) {
            System.out.println("今天是" + year + "年的第" + date + "天");
        }

        System.out.println("请输入想要到达的年份：");
        int year1 = input.nextInt();
        System.out.print("请输入月份：");
        int month1 = input.nextInt();
        System.out.print("请输入日份：");
        int date1 = input.nextInt();

        switch (month1 - 1) {
            case 11:
                date1 += 30;
            case 10:
                date1 += 31;
            case 9:
                date1 += 30;
            case 8:
                date1 += 31;
            case 7:
                date1 += 31;
            case 6:
                date1 += 30;
            case 5:
                date1 += 31;
            case 4:
                date1 += 30;
            case 3:
                date1 += 31;
            case 2:
                if ((year1 % 400 == 0) || (year1 % 4 == 0 && year1 % 100 != 0) && (year1 != 0)) {
                    date1 += 29;
                } else {
                    date1 += 28;
                }
            case 1:
                date1 += 31;
                break;
            default:
                System.out.println("请输入正确月份");
                break;
        }

        if (month1 >= 1 && month1 <= 12) {
            System.out.println("今天是" + year1 + "年的第" + date1 + "天");
        }

        int ping = 0;
        int run = 0;
        int daYear = 0;
        int xiaoYear = 0;

        if (year > year1) {
            daYear = year;
            xiaoYear = year1;
        } else {
            daYear = year1;
            xiaoYear = year;
        }

        for (; daYear > year || daYear > year1; daYear--) {

            if ((daYear % 400 == 0) || (daYear % 4 == 0 && daYear % 100 != 0) && (daYear != 0)) {
                run++;
            } else {
                ping++;
                
            }
        }
        System.out.println("1900年至今有" + run + "个闰年");
        System.out.println("1900年至今有" + ping + "个平年");
        System.out.println("1900年至今有" + (run * 366 + ping * 365 + date - 1) + "天");
    }
}

