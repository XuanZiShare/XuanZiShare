package LearnJava.天数相差计算器;
//天数相差计算器，思路3

import java.util.Scanner;

public class 天数相差计算器03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("欢迎使用年份相差计算器");
        System.out.print("请输入年份：");
        int year = input.nextInt();
        System.out.print("请输入月份：");
        int month = input.nextInt();
        System.out.print("请输入日份：");
        int date = input.nextInt();

        switch (month - 1) {
            case 11:
                date += 30;
            case 10:
                date += 31;
            case 9:
                date += 30;
            case 8:
                date += 31;
            case 7:
                date += 31;
            case 6:
                date += 30;
            case 5:
                date += 31;
            case 4:
                date += 30;
            case 3:
                date += 31;
            case 2:
                if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0) && (year != 0)) {
                    date += 29;
                } else {
                    date += 28;
                }
            case 1:
                date += 31;
                break;
            default:
                System.out.println("请输入正确月份");
                break;
        }

        if (month >= 1 && month <= 12) {
            System.out.println("今天是" + year + "年的第" + date + "天");
//上面和2是一样的
            int ping = 0;
            int run = 0;
//定义平年数量和闰年数量
            for (; year > 1900; year--) {
//                输入年到1900年有多少平年闰年
                if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0) && (year != 0)) {
                    run++;
                } else {
                    ping++;
                }
                System.out.println(run);
                System.out.println(ping);
//如果是平年，平念数加一，不然闰年加1
                System.out.println(run * 366 + ping * 365 + date - 1);
                //总天数
            }
            System.out.println("1900年至今有" + run + "个闰年");
            System.out.println("1900年至今有" + ping + "个平年");
            System.out.println("1900年至今有" + (run * 366 + ping * 365 + date - 1) + "天");
        }


    }
}
