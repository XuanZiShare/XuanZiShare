package LearnJava.小练习;

import java.util.Arrays;

public class XuanZi07 {
    public static void main(String[] args) {
        String[] name = new String[]{"tom", "jerry", "james", "jack", "marry"};
        Arrays.sort(name);
        //对数组名字排序然后输出
        for (int i = 0; i < name.length; i++) {
            System.out.print(name[i] + "\t");
        }
    }
}
