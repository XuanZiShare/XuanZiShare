package LearnJava.小练习;

public class Fish {
    String size;
    String color;
    String lei;

    //定义三个属性
    public void swimming() {
        System.out.println("游泳");
    }

    //游泳方法
    public void eat() {
        System.out.println("吃鱼食");
    }
//    吃饭方法
}
