package LearnJava.小练习;
//判断一句话里面有几种符号

import java.util.Scanner;

public class XuanZi03 {

    public static int[] count(String sentence) {

        //请在此处补充代码

        int[] result = new int[4];

        for (int i = 0; i < sentence.length(); i++) {
            char c = sentence.charAt(i);
            if ((c >= 'a' && c <= 'z') || c >= 'A' && c <= 'Z') {
                result[0]++;
            } else if (c == ' ') {
                result[1]++;
            } else if (c >= '0' && c <= '9') {
                result[2]++;
            } else {
                result[3]++;
            }
        }
        return result;
    }


    public static void main(String[] args) {

        System.out.println("请输入一行内容，以回车符结尾");

        Scanner input = new Scanner(System.in);

        String sentence = input.nextLine();

        int[] result = count(sentence);

        System.out.println("该行包含的英文字母、空格、数字及其它字符的个数分别为：");

        System.out.println(result[0] + ", " + result[1] + ", " + result[2] + ", " + result[3]);

    }

}
