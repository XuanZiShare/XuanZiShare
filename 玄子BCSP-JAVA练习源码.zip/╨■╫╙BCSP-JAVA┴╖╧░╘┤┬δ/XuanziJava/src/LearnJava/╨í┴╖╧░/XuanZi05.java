package LearnJava.小练习;


public class XuanZi05 {
    public static void main(String[] args) {
        int[] sums = {88, 14, 90, 7, 22, 5};
        //按要求声明数组赋值
        int max = sums[0];
        //定义最大值，为数组第一下标
        int min = sums[0];
        //定义最小值，为数组第一下标

        for (int sum : sums) {
            //求最大值
            if (sum > max) {
                max = sum;
                //如果当前数组值大于当前max就把当前数组值设为max
            }
        }

        System.out.println("最大值：" + max);
        //输出最大值

        for (int i = 0; i < sums.length; i++) {
            //求最小值
            if (sums[i] < min) {
                min = sums[i];
                //如果当前数组值小于当前min就把当前数组值设为min
            }
        }

        System.out.println("最小值：" + min);
        //输出最小值

    }

}
