package LearnJava.小练习;

import java.util.Scanner;

public class XuanZi02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //Scanner 扫描器
        for (int i = 1; i <= 3; i++) {
            // 定义三次机会
            System.out.print("请输入用户名：");
            String jiez = input.next();
            System.out.print("请输入密码：");
            String jiem = input.next();
            // 接收用户输入的账号密码
            if (jiez.equals("jim") && jiem.equals("123456")) {
                System.out.println("欢迎登录MyShopping系统！");
                // 如果账号密码相同就提示登录成功
                break;
                // 立即终止程序
            } else {
                // 输入错误就提示剩余机会
                System.out.println("输入错误！你还有" + (3 - i) + "机会!");
                if (i == 3) {
                    System.out.println("对不起，您3次均输入错误！");
                    // 三次均错误提示用户没机会了
                }
            }
        }
    }
}
