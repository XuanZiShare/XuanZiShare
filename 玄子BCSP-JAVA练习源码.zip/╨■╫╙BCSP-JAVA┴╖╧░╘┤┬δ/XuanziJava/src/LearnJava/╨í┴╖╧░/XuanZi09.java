package LearnJava.小练习;

import java.util.Scanner;

public class XuanZi09 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("输入一个正整数");
        int num = input.nextInt();
        while (num != 0) {
            int a = num % 10;
            //把用户输入的数%一下取最后一位
            System.out.print(a + "\t");
            //取到最后一位直接输出
            num = num / 10;
            //因为最后一位已经输出过了，所以把用户输入的数减去最后一位的数，就是除10取证。
        }
        //循环结束后在进入一次循环
    }
}
