package LearnJava.小练习;

public class FishTest {
    public static void main(String[] args) {
        Fish fish = new Fish();
        //调用方法
        fish.size = "5米";
        fish.color = "金色";
        fish.lei = "锦鲤";
//赋值
        System.out.println("这是一条" + fish.size + "长的" + fish.color + fish.lei);
        //整合输出
        fish.eat();
        fish.swimming();
        //调用方法
    }
}
