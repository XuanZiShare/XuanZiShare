package LearnJava.进制转换;

import java.util.Scanner;

public class 二进制转换十进制 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //先判断有几位数
        //输入数*输入位数减去1的平方
        //转换后数值相加
        //输出最终结果
/*
        int k=0 ;

        System.out.println("请输入二进制位数：");
        double erjin= input.nextDouble();
        for (;erjin>0;) {
            System.out.println("请输入第" + erjin + "位数");
            int j = input.nextInt();
            double c;
            if (j == 0) {
                c = 1;
            } else {
                c = Math.pow((erjin - 1), 2);
            }
            double m = (c * j);
            k += m;
            erjin--;

        }
        System.out.println(k);
         */

        System.out.println("请输入二进制数字：");
        int erjinzhi = input.nextInt();

        int shijinzhi = 0, p = 0;
        while (erjinzhi != 0) {
            shijinzhi += ((erjinzhi % 10) * Math.pow(2, p));
            erjinzhi = erjinzhi / 10;
            p++;
        }
        System.out.println(shijinzhi);
    }
}

